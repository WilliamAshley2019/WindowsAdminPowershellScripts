@echo off
powershell -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0FileSlicer_v17.ps1"
