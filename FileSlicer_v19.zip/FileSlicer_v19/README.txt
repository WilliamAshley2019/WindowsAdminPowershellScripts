File Slicer v19
===============
1. Right-click the zip > Properties > Unblock (if shown), then extract.
2. Double-click Run_FileSlicer.bat
3. Press F1 for the manual (MANUAL.html), F2 for the terminal, F5 to slice.

v19: fixed "RUN ?" / "LOAD?" crashing with a null-valued-expression error.
     They now list your .bas files as a numbered menu in the terminal
     (type a number to run it) instead of relying only on a file-picker
     dialog. Type B at that prompt to still use a dialog if you want one;
     if the dialog itself fails, you now get a specific error instead of
     a generic crash.
v18: networking - HTTPGET/HTTPPOST, FTPLS/FTPGET/FTPPUT, NETOPEN/NETSEND/
     NETREAD/NETCLOSE (raw TCP). Bundled: HTTPGET, FTP, TELNET, IRC.
     SSH: use \c ssh user@host (key-based auth only).
v17: fixed "Unable to find type [System.Func]" on Windows PowerShell 5.1.
v16: \c / \p / \7 shell pass-through, MANUAL command and F1.
