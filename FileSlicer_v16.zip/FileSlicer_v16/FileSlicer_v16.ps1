﻿<#
=====================================================================
  斬る  File Slicer v16  (ファイル・スライサー)
  --------------------------------------------------------------
  Run:  double-click Run_FileSlicer.bat   or
        powershell -ExecutionPolicy Bypass -File .\FileSlicer_v16.ps1

  Search   : file types (wav mp3 / * / presets), name wildcard or regex,
             text inside files, size, date, duplicates, CSV export
  Terminal : F2 - a Commodore-64 style terminal (DOS + BASIC V2)
      LOAD"$",8 / LIST      FIND  EXT  GREP  REGEX  BIG  DUPES  SORT ...
      RUN ?          pick a .BAS file with a file dialog and run it
      RUN "NAME"     run a .BAS from this folder or the Programs folder
      PROGS          list the bundled programs (BIGFILES, DUPEHUNT ...)
      BASIC programs can drive the slicer:  CMD "SLICE MIN=100"
                                            N=RC(0) : PRINT RP$(1)
      \c dir  \p Get-Date  \7 ...   pass a line to cmd / PowerShell / pwsh
      MANUAL (or F1) opens MANUAL.html
  Hotkeys  : F5 = Slice   F2 = Terminal   F1 = Manual   Esc = Stop / RUN-STOP
=====================================================================
#>

# WinForms wants STA. Relaunch ourselves if needed.
if ([System.Threading.Thread]::CurrentThread.GetApartmentState() -ne 'STA') {
    $exe = (Get-Process -Id $PID).Path
    Start-Process -FilePath $exe -ArgumentList @('-STA', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"")
    return
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName Microsoft.VisualBasic
[System.Windows.Forms.Application]::EnableVisualStyles()

# ---------------------------------------------------------------------
#  C# engine: threaded slicer + BASIC V2 interpreter
# ---------------------------------------------------------------------
$csharp = @'
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

// ======================================================================
//  SLICER ENGINE  (background thread, no UI dependencies)
// ======================================================================
public class SliceHit
{
    public string FullName;
    public string Name;
    public string Ext;
    public string Dir;
    public long Length;
    public DateTime Modified;
    public string Extra = "";
}

public class SliceOptions
{
    public string Root;
    public string[] Extensions = new string[0];
    public string NamePattern = "";
    public bool UseRegex;
    public long MinBytes;
    public long MaxBytes = Int64.MaxValue;
    public bool UseDate;
    public DateTime DateValue;
    public bool DateNewer = true;
    public string ContentText = "";
    public bool IncludeHidden = true;
    public bool Recurse = true;
    public bool FindDupes;
    public long ContentMaxBytes = 64L * 1024 * 1024;
}

public class Slicer
{
    public volatile bool Cancel;
    public volatile bool Done;
    public long Scanned;
    public long Matched;
    public long DirsSeen;
    public volatile string CurrentDir = "";
    public volatile string Phase = "";
    public string Error = "";
    public List<SliceHit> Hits = new List<SliceHit>();
    private Thread worker;

    public void Start(SliceOptions o)
    {
        worker = new Thread(delegate() { Run(o); });
        worker.IsBackground = true;
        worker.Start();
    }

    private static Regex BuildNameRegex(SliceOptions o)
    {
        if (String.IsNullOrEmpty(o.NamePattern)) return null;
        string p = o.NamePattern;
        if (o.UseRegex) return new Regex(p, RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
        if (p.IndexOf('*') < 0 && p.IndexOf('?') < 0)
            return new Regex(Regex.Escape(p), RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
        string body = Regex.Escape(p).Replace("\\*", ".*").Replace("\\?", ".");
        return new Regex("^" + body + "$", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
    }

    private void Run(SliceOptions o)
    {
        try
        {
            Regex nameRx = BuildNameRegex(o);
            Dictionary<string, bool> exts = null;
            if (o.Extensions != null && o.Extensions.Length > 0)
            {
                exts = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);
                foreach (string e in o.Extensions) exts[e] = true;
            }
            string needle = null;
            if (!String.IsNullOrEmpty(o.ContentText))
                needle = Encoding.GetEncoding(28591).GetString(Encoding.UTF8.GetBytes(o.ContentText));

            Phase = "Scanning";
            Stack<string> stack = new Stack<string>();
            stack.Push(o.Root);
            while (stack.Count > 0 && !Cancel)
            {
                string dir = stack.Pop();
                CurrentDir = dir;
                DirsSeen++;
                DirectoryInfo di;
                FileInfo[] files;
                try
                {
                    di = new DirectoryInfo(dir);
                    files = di.GetFiles();
                }
                catch { continue; }

                foreach (FileInfo f in files)
                {
                    if (Cancel) break;
                    Scanned++;
                    try
                    {
                        if (Accept(f, o, exts, nameRx, needle))
                        {
                            SliceHit h = new SliceHit();
                            h.FullName = f.FullName;
                            h.Name = f.Name;
                            h.Ext = f.Extension.ToLowerInvariant();
                            h.Dir = f.DirectoryName;
                            h.Length = f.Length;
                            h.Modified = f.LastWriteTime;
                            Hits.Add(h);
                            Matched++;
                        }
                    }
                    catch { }
                }

                if (o.Recurse)
                {
                    try
                    {
                        foreach (DirectoryInfo sd in di.GetDirectories())
                        {
                            if ((sd.Attributes & FileAttributes.ReparsePoint) != 0) continue;
                            stack.Push(sd.FullName);
                        }
                    }
                    catch { }
                }
            }
            if (o.FindDupes && !Cancel) FindDuplicates();
        }
        catch (Exception ex)
        {
            Error = ex.Message;
        }
        Done = true;
    }

    private bool Accept(FileInfo f, SliceOptions o, Dictionary<string, bool> exts, Regex rx, string needle)
    {
        if (!o.IncludeHidden && (f.Attributes & FileAttributes.Hidden) != 0) return false;
        long len = f.Length;
        if (len < o.MinBytes || len > o.MaxBytes) return false;
        if (exts != null && !exts.ContainsKey(f.Extension)) return false;
        if (rx != null && !rx.IsMatch(f.Name)) return false;
        if (o.UseDate)
        {
            if (o.DateNewer) { if (f.LastWriteTime < o.DateValue) return false; }
            else { if (f.LastWriteTime >= o.DateValue) return false; }
        }
        if (needle != null)
        {
            if (len == 0 || len > o.ContentMaxBytes) return false;
            if (!FileContains(f.FullName, needle)) return false;
        }
        return true;
    }

    private bool FileContains(string path, string needle)
    {
        try
        {
            Encoding enc = Encoding.GetEncoding(28591);
            using (FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read,
                   FileShare.ReadWrite | FileShare.Delete, 65536))
            {
                byte[] buf = new byte[1048576];
                string carry = "";
                int n;
                while ((n = fs.Read(buf, 0, buf.Length)) > 0)
                {
                    if (Cancel) return false;
                    string chunk = carry + enc.GetString(buf, 0, n);
                    if (chunk.IndexOf(needle, StringComparison.OrdinalIgnoreCase) >= 0) return true;
                    int keep = Math.Min(chunk.Length, needle.Length - 1);
                    carry = keep > 0 ? chunk.Substring(chunk.Length - keep) : "";
                }
            }
        }
        catch { }
        return false;
    }

    // ---- duplicate finder: size -> first 64KB hash -> full hash ----
    private void FindDuplicates()
    {
        Phase = "Grouping by size";
        Dictionary<long, List<SliceHit>> bySize = new Dictionary<long, List<SliceHit>>();
        foreach (SliceHit h in Hits)
        {
            if (h.Length <= 0) continue;
            List<SliceHit> l;
            if (!bySize.TryGetValue(h.Length, out l))
            {
                l = new List<SliceHit>();
                bySize[h.Length] = l;
            }
            l.Add(h);
        }
        List<SliceHit> result = new List<SliceHit>();
        foreach (KeyValuePair<long, List<SliceHit>> kv in bySize)
        {
            if (Cancel) break;
            if (kv.Value.Count < 2) continue;
            Dictionary<string, List<SliceHit>> quick = GroupByHash(kv.Value, 65536);
            foreach (List<SliceHit> qg in quick.Values)
            {
                if (Cancel) break;
                if (qg.Count < 2) continue;
                Dictionary<string, List<SliceHit>> full = GroupByHash(qg, -1);
                foreach (KeyValuePair<string, List<SliceHit>> fg in full)
                {
                    if (fg.Value.Count < 2) continue;
                    string tag = fg.Key.Substring(0, 8);
                    foreach (SliceHit h in fg.Value)
                    {
                        h.Extra = tag;
                        result.Add(h);
                    }
                }
            }
        }
        Hits = result;
        Matched = result.Count;
    }

    private Dictionary<string, List<SliceHit>> GroupByHash(List<SliceHit> src, int limit)
    {
        Dictionary<string, List<SliceHit>> d = new Dictionary<string, List<SliceHit>>();
        foreach (SliceHit h in src)
        {
            if (Cancel) break;
            Phase = "Hashing " + h.Name;
            string key = HashFile(h.FullName, limit);
            if (key == null) continue;
            List<SliceHit> l;
            if (!d.TryGetValue(key, out l))
            {
                l = new List<SliceHit>();
                d[key] = l;
            }
            l.Add(h);
        }
        return d;
    }

    private string HashFile(string path, int limit)
    {
        try
        {
            using (FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read,
                   FileShare.ReadWrite | FileShare.Delete, 65536))
            using (SHA1 sha = SHA1.Create())
            {
                byte[] hash;
                if (limit > 0)
                {
                    byte[] buf = new byte[limit];
                    int total = 0;
                    int n;
                    while (total < limit && (n = fs.Read(buf, total, limit - total)) > 0) total += n;
                    hash = sha.ComputeHash(buf, 0, total);
                }
                else
                {
                    hash = sha.ComputeHash(fs);
                }
                StringBuilder sb = new StringBuilder();
                foreach (byte b in hash) sb.Append(b.ToString("x2"));
                return sb.ToString();
            }
        }
        catch { return null; }
    }
}


// ======================================================================
//  SHELL RUNNER  (cmd / PowerShell pass-through, streamed output)
// ======================================================================
public class ShellRunner
{
    private Process proc;
    private StringBuilder buf = new StringBuilder();
    private object lk = new object();
    public string StartError = "";
    public int ExitCode;

    private void Append(string s)
    {
        lock (lk) { buf.Append(s); }
    }

    public string Take()
    {
        lock (lk)
        {
            string s = buf.ToString();
            buf.Length = 0;
            return s;
        }
    }

    public bool Start(string file, string args, string workDir, int codePage)
    {
        try
        {
            ProcessStartInfo psi = new ProcessStartInfo(file, args);
            psi.WorkingDirectory = workDir;
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;
            psi.RedirectStandardInput = true;
            Encoding enc;
            try { enc = Encoding.GetEncoding(codePage); } catch { enc = new UTF8Encoding(false); }
            psi.StandardOutputEncoding = enc;
            psi.StandardErrorEncoding = enc;
            proc = new Process();
            proc.StartInfo = psi;
            proc.OutputDataReceived += delegate(object s, DataReceivedEventArgs e) { if (e.Data != null) Append(e.Data + "\n"); };
            proc.ErrorDataReceived += delegate(object s, DataReceivedEventArgs e) { if (e.Data != null) Append(e.Data + "\n"); };
            proc.Start();
            proc.BeginOutputReadLine();
            proc.BeginErrorReadLine();
            try { proc.StandardInput.Close(); } catch { }
            return true;
        }
        catch (Exception ex)
        {
            StartError = ex.Message;
            proc = null;
            return false;
        }
    }

    public bool IsDone()
    {
        if (proc == null) return true;
        if (!proc.HasExited) return false;
        try { proc.WaitForExit(1000); ExitCode = proc.ExitCode; } catch { }
        return true;
    }

    public void Kill()
    {
        if (proc == null) return;
        try
        {
            ProcessStartInfo k = new ProcessStartInfo("taskkill", "/PID " + proc.Id.ToString() + " /T /F");
            k.CreateNoWindow = true;
            k.UseShellExecute = false;
            Process kp = Process.Start(k);
            if (kp != null) kp.WaitForExit(3000);
        }
        catch
        {
            try { proc.Kill(); } catch { }
        }
    }
}

// ======================================================================
//  BASIC V2-STYLE INTERPRETER  (tribute to the Commodore 64)
// ======================================================================
public class BasicError : Exception
{
    public BasicError(string m) : base(m) { }
}

public enum BasState { Idle, Running, Input, Ended, Error }

public class C64Basic
{
    public Action<string> Out;
    public Action<int, int> OnPoke;
    public Action OnReset;
    public Func<string, string> HostCmd;                 // returns null/"" on success, else error text
    public Func<string, object[], string> HostStr;       // host string functions (RP$, RN$, FS$ ...)
    public Func<string, object[], double> HostNum;       // host numeric functions (RC, RS)
    public SortedDictionary<int, string> Prog = new SortedDictionary<int, string>();
    public BasState State = BasState.Idle;
    public byte[] Mem = new byte[65536];
    public int Col;

    private class ForFrame { public string Var; public double Limit; public double Step; public int Li; public int Si; }
    private class ArrData { public int[] Dims; public object[] Data; }

    private Dictionary<string, object> vars = new Dictionary<string, object>();
    private Dictionary<string, ArrData> arrays = new Dictionary<string, ArrData>();
    private List<ForFrame> fors = new List<ForFrame>();
    private Stack<int[]> gosubs = new Stack<int[]>();
    private List<int> nums = new List<int>();
    private List<List<string>> stmts = new List<List<string>>();
    private Dictionary<int, int> lineIdx = new Dictionary<int, int>();
    private List<object> dataItems = new List<object>();
    private int dataPtr;
    private int li;
    private int si;
    private bool jumped;
    private string src = "";
    private int p;
    private StringBuilder outBuf = new StringBuilder();
    private List<string> inputNames = new List<string>();
    private List<string> inputBuf = new List<string>();
    private Random rnd = new Random();
    private int t0 = Environment.TickCount;

    private static readonly string[] Kw = {
        "PRINT", "INPUT", "GOSUB", "GOTO", "RETURN", "RESTORE", "READ", "DATA", "REM",
        "FOR", "NEXT", "END", "STOP", "DIM", "POKE", "SYS", "LET", "IF", "CLR", "CMD" };
    private static readonly string[] HostNumFuncs = { "RC", "RS" };
    private static readonly string[] HostStrFuncs = { "RP$", "RN$", "RD$", "RX$", "RG$", "FS$", "CWD$" };
    private static readonly string[] Funcs = {
        "ABS", "INT", "SQR", "SIN", "COS", "TAN", "ATN", "LOG", "EXP", "SGN", "RND",
        "LEN", "VAL", "ASC", "CHR$", "STR$", "LEFT$", "RIGHT$", "MID$", "PEEK", "FRE", "POS" };

    public C64Basic()
    {
        Mem[53280] = 14;
        Mem[53281] = 6;
        Mem[646] = 14;
    }

    // ---------- public API ----------
    public void SetLine(int n, string text)
    {
        text = Normalize(text.Trim());
        if (text.Length == 0) Prog.Remove(n);
        else Prog[n] = text;
    }

    public void ClearProgram()
    {
        Prog.Clear();
        ClearVars();
        State = BasState.Idle;
    }

    public void Run()
    {
        ClearVars();
        Prepare(null);
        li = 0; si = 0;
        State = nums.Count == 0 ? BasState.Ended : BasState.Running;
    }

    public void RunFrom(int n)
    {
        ClearVars();
        Prepare(null);
        int i;
        if (!lineIdx.TryGetValue(n, out i))
        {
            W("?UNDEF'D STATEMENT  ERROR\n");
            Flush();
            State = BasState.Error;
            return;
        }
        li = i; si = 0;
        State = BasState.Running;
    }

    public void Direct(string line)
    {
        fors.Clear();
        gosubs.Clear();
        Prepare(Normalize(line));
        li = 0; si = 0;
        State = BasState.Running;
    }

    public void Step(int budget)
    {
        try
        {
            while (State == BasState.Running && budget-- > 0)
            {
                while (li < nums.Count && si >= stmts[li].Count)
                {
                    if (nums[li] == -1) { State = BasState.Ended; return; }
                    li++; si = 0;
                }
                if (li >= nums.Count) { State = BasState.Ended; return; }
                jumped = false;
                try
                {
                    ExecText(stmts[li][si]);
                }
                catch (BasicError e) { Fail(e.Message); return; }
                catch (Exception) { Fail("SYNTAX"); return; }
                if (!jumped) si++;
                if (outBuf.Length > 4000) break;
            }
        }
        finally { Flush(); }
    }

    public void ProvideInput(string line)
    {
        if (State != BasState.Input) return;
        if (inputNames.Count == 1) inputBuf.Add(line.Trim());
        else foreach (string part in line.Split(',')) inputBuf.Add(part.Trim());
        if (inputBuf.Count < inputNames.Count) { W("?? "); Flush(); return; }
        List<object> vals = new List<object>();
        bool ok = true;
        for (int i = 0; i < inputNames.Count; i++)
        {
            string nm = inputNames[i];
            string txt = inputBuf[i];
            if (nm.EndsWith("$")) { vals.Add(txt); continue; }
            double d = 0;
            if (txt.Length > 0 && !Double.TryParse(txt, NumberStyles.Float, CultureInfo.InvariantCulture, out d))
            {
                ok = false;
                break;
            }
            vals.Add(d);
        }
        inputBuf.Clear();
        if (!ok) { W("?REDO FROM START\n? "); Flush(); return; }
        for (int i = 0; i < inputNames.Count; i++) vars[inputNames[i]] = vals[i];
        State = BasState.Running;
    }

    public void Break()
    {
        if (State != BasState.Running && State != BasState.Input) return;
        if (Col != 0) W("\n");
        int ln = CurLine();
        W("BREAK" + (ln >= 0 ? " IN " + ln.ToString() : "") + "\n");
        State = BasState.Idle;
        Flush();
    }

    public void Flush()
    {
        if (outBuf.Length > 0 && Out != null)
        {
            string t = outBuf.ToString();
            outBuf.Length = 0;
            Out(t);
        }
    }

    // ---------- helpers ----------
    private int CurLine()
    {
        if (li >= 0 && li < nums.Count) return nums[li];
        return -1;
    }

    private void W(string s)
    {
        for (int i = 0; i < s.Length; i++)
        {
            char c = s[i];
            if (c == '\n') Col = 0;
            else if (c >= 32 && (c < 128 || c >= 160)) Col++;
        }
        outBuf.Append(s);
    }

    private void Fail(string msg)
    {
        State = BasState.Error;
        if (Col != 0) W("\n");
        int ln = CurLine();
        W("?" + msg + "  ERROR" + (ln >= 0 ? " IN " + ln.ToString() : "") + "\n");
    }

    private static BasicError Syn() { return new BasicError("SYNTAX"); }
    private static BasicError TypeMis() { return new BasicError("TYPE MISMATCH"); }
    private static BasicError Illegal() { return new BasicError("ILLEGAL QUANTITY"); }

    private void ClearVars()
    {
        vars.Clear();
        arrays.Clear();
        fors.Clear();
        gosubs.Clear();
        dataPtr = 0;
    }

    public static string Normalize(string line)
    {
        StringBuilder sb = new StringBuilder();
        bool q = false;
        foreach (char c in line)
        {
            if (c == '"') q = !q;
            sb.Append(q ? c : Char.ToUpperInvariant(c));
        }
        return sb.ToString();
    }

    private static List<string> SplitStatements(string line)
    {
        List<string> res = new List<string>();
        StringBuilder sb = new StringBuilder();
        bool q = false;
        foreach (char c in line)
        {
            if (c == '"') q = !q;
            if (c == ':' && !q)
            {
                string t = sb.ToString().TrimStart();
                if (t.StartsWith("REM", StringComparison.Ordinal)) { sb.Append(c); continue; }
                res.Add(sb.ToString());
                sb.Length = 0;
                continue;
            }
            sb.Append(c);
        }
        res.Add(sb.ToString());
        return res;
    }

    private void Prepare(string direct)
    {
        nums = new List<int>();
        stmts = new List<List<string>>();
        lineIdx = new Dictionary<int, int>();
        dataItems = new List<object>();
        if (direct != null)
        {
            nums.Add(-1);
            stmts.Add(SplitStatements(direct));
        }
        foreach (KeyValuePair<int, string> kv in Prog)
        {
            lineIdx[kv.Key] = nums.Count;
            nums.Add(kv.Key);
            List<string> sl = SplitStatements(Normalize(kv.Value));
            stmts.Add(sl);
            foreach (string s in sl)
            {
                string t = s.Trim();
                if (t.StartsWith("DATA", StringComparison.Ordinal)) CollectData(t.Substring(4));
            }
        }
    }

    private void CollectData(string body)
    {
        int i = 0;
        while (i <= body.Length)
        {
            while (i < body.Length && body[i] == ' ') i++;
            object item;
            if (i < body.Length && body[i] == '"')
            {
                int e = body.IndexOf('"', i + 1);
                string s;
                if (e < 0) { s = body.Substring(i + 1); i = body.Length; }
                else { s = body.Substring(i + 1, e - i - 1); i = e + 1; }
                item = s;
                while (i < body.Length && body[i] != ',') i++;
            }
            else
            {
                int e = body.IndexOf(',', i);
                string s;
                if (e < 0) { s = body.Substring(i); i = body.Length; }
                else { s = body.Substring(i, e - i); i = e; }
                s = s.Trim();
                double d;
                if (Double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out d)) item = d;
                else item = s;
            }
            dataItems.Add(item);
            if (i >= body.Length) break;
            i++;
        }
    }

    // ---------- lexer helpers over (src, p) ----------
    private void Ws() { while (p < src.Length && src[p] == ' ') p++; }
    private bool AtEnd() { Ws(); return p >= src.Length; }
    private char Pk() { Ws(); return p < src.Length ? src[p] : '\0'; }
    private bool Acc(char c) { if (Pk() == c) { p++; return true; } return false; }

    private bool AccWord(string w)
    {
        Ws();
        if (String.Compare(src, p, w, 0, w.Length, StringComparison.Ordinal) == 0)
        {
            int e = p + w.Length;
            if (e >= src.Length || !Char.IsLetter(src[e])) { p = e; return true; }
        }
        return false;
    }

    private string ReadIdent()
    {
        Ws();
        int s = p;
        while (p < src.Length && Char.IsLetterOrDigit(src[p])) p++;
        if (p < src.Length && (src[p] == '$' || src[p] == '%')) p++;
        return src.Substring(s, p - s);
    }

    // ---------- value helpers ----------
    private static double Num(object o)
    {
        if (o is double) return (double)o;
        throw TypeMis();
    }

    private static string Str(object o)
    {
        if (o is string) return (string)o;
        throw TypeMis();
    }

    private static string FmtCore(double d)
    {
        string s;
        if (d == Math.Floor(d) && Math.Abs(d) < 1e9) s = ((long)d).ToString(CultureInfo.InvariantCulture);
        else s = d.ToString("G9", CultureInfo.InvariantCulture);
        if (s.StartsWith("0.")) s = s.Substring(1);
        else if (s.StartsWith("-0.")) s = "-" + s.Substring(2);
        return (d >= 0 ? " " : "") + s;
    }

    // ---------- expression parser ----------
    private object ParseExpr() { return ParseOr(); }

    private object ParseOr()
    {
        object l = ParseAnd();
        while (AccWord("OR"))
        {
            object r = ParseAnd();
            l = (double)((long)Num(l) | (long)Num(r));
        }
        return l;
    }

    private object ParseAnd()
    {
        object l = ParseNot();
        while (AccWord("AND"))
        {
            object r = ParseNot();
            l = (double)((long)Num(l) & (long)Num(r));
        }
        return l;
    }

    private object ParseNot()
    {
        if (AccWord("NOT")) return (double)(~(long)Num(ParseNot()));
        return ParseCmp();
    }

    private int Compare(object a, object b)
    {
        if (a is string && b is string) return String.CompareOrdinal((string)a, (string)b);
        if (a is double && b is double) return ((double)a).CompareTo((double)b);
        throw TypeMis();
    }

    private object ParseCmp()
    {
        object l = ParseAdd();
        while (true)
        {
            Ws();
            string op = "";
            while (p < src.Length && (src[p] == '<' || src[p] == '>' || src[p] == '=') && op.Length < 2)
            {
                op += src[p];
                p++;
            }
            if (op.Length == 0) return l;
            object r = ParseAdd();
            int c = Compare(l, r);
            bool res;
            switch (op)
            {
                case "=": res = c == 0; break;
                case "<>": case "><": res = c != 0; break;
                case "<": res = c < 0; break;
                case ">": res = c > 0; break;
                case "<=": case "=<": res = c <= 0; break;
                case ">=": case "=>": res = c >= 0; break;
                default: throw Syn();
            }
            l = res ? -1.0 : 0.0;
        }
    }

    private object ParseAdd()
    {
        object l = ParseMul();
        while (true)
        {
            char c = Pk();
            if (c == '+')
            {
                p++;
                object r = ParseMul();
                if (l is string && r is string) l = (string)l + (string)r;
                else l = Num(l) + Num(r);
            }
            else if (c == '-')
            {
                p++;
                object r = ParseMul();
                l = Num(l) - Num(r);
            }
            else return l;
        }
    }

    private object ParseMul()
    {
        object l = ParseUnary();
        while (true)
        {
            char c = Pk();
            if (c == '*')
            {
                p++;
                object r = ParseUnary();
                l = Num(l) * Num(r);
            }
            else if (c == '/')
            {
                p++;
                object r = ParseUnary();
                double d = Num(r);
                if (d == 0) throw new BasicError("DIVISION BY ZERO");
                l = Num(l) / d;
            }
            else return l;
        }
    }

    private object ParseUnary()
    {
        char c = Pk();
        if (c == '-') { p++; return -Num(ParseUnary()); }
        if (c == '+') { p++; return ParseUnary(); }
        return ParsePow();
    }

    private object ParsePow()
    {
        object b = ParsePrimary();
        while (Pk() == '^')
        {
            p++;
            object e = ParseUnary();
            b = Math.Pow(Num(b), Num(e));
        }
        return b;
    }

    private object ParseNumber()
    {
        int s = p;
        while (p < src.Length && (Char.IsDigit(src[p]) || src[p] == '.')) p++;
        if (p < src.Length && src[p] == 'E' && p + 1 < src.Length &&
            (Char.IsDigit(src[p + 1]) ||
             ((src[p + 1] == '+' || src[p + 1] == '-') && p + 2 < src.Length && Char.IsDigit(src[p + 2]))))
        {
            p += 2;
            while (p < src.Length && Char.IsDigit(src[p])) p++;
        }
        double d;
        if (!Double.TryParse(src.Substring(s, p - s), NumberStyles.Float, CultureInfo.InvariantCulture, out d)) throw Syn();
        return d;
    }

    private object ParsePrimary()
    {
        char c = Pk();
        if (c == '(')
        {
            p++;
            object v = ParseExpr();
            if (!Acc(')')) throw Syn();
            return v;
        }
        if (c == '"')
        {
            p++;
            int e = src.IndexOf('"', p);
            string s;
            if (e < 0) { s = src.Substring(p); p = src.Length; }
            else { s = src.Substring(p, e - p); p = e + 1; }
            return s;
        }
        if (Char.IsDigit(c) || c == '.') return ParseNumber();
        if (Char.IsLetter(c))
        {
            string id = ReadIdent();
            if (Pk() == '(')
            {
                p++;
                List<object> args = new List<object>();
                if (!Acc(')'))
                {
                    do { args.Add(ParseExpr()); } while (Acc(','));
                    if (!Acc(')')) throw Syn();
                }
                if (Array.IndexOf(Funcs, id) >= 0) return CallFunc(id, args);
                if (Array.IndexOf(HostNumFuncs, id) >= 0 || Array.IndexOf(HostStrFuncs, id) >= 0) return CallHost(id, args);
                ArrData a = GetArrayData(id, args.Count);
                return a.Data[ArrIndex(a, args)];
            }
            return GetVar(id);
        }
        throw Syn();
    }

    private object GetVar(string id)
    {
        switch (id)
        {
            case "TI": return (double)((long)(Environment.TickCount - t0) * 60L / 1000L);
            case "TI$": return DateTime.Now.ToString("HHmmss");
            case "CWD$": return HostStr == null ? "" : CallHost("CWD$", new List<object>());
            case "ST": return 0.0;
            case "PI": return Math.PI;
        }
        object v;
        if (vars.TryGetValue(id, out v)) return v;
        if (id.EndsWith("$")) return "";
        return 0.0;
    }

    private static double ParseVal(string s)
    {
        Match m = Regex.Match(s, @"^\s*[-+]?(\d+\.?\d*|\.\d+)([eE][-+]?\d+)?");
        if (!m.Success) return 0.0;
        double d;
        if (Double.TryParse(m.Value, NumberStyles.Float, CultureInfo.InvariantCulture, out d)) return d;
        return 0.0;
    }

    private object CallHost(string id, List<object> a)
    {
        try
        {
            if (Array.IndexOf(HostNumFuncs, id) >= 0)
            {
                if (HostNum == null) throw new BasicError("UNDEF'D FUNCTION");
                return HostNum(id, a.ToArray());
            }
            if (HostStr == null) throw new BasicError("UNDEF'D FUNCTION");
            return HostStr(id, a.ToArray());
        }
        catch (BasicError) { throw; }
        catch (Exception ex) { throw new BasicError(ex.GetBaseException().Message.ToUpperInvariant()); }
    }

    private object CallFunc(string id, List<object> a)
    {
        if (a.Count < 1) throw Syn();
        switch (id)
        {
            case "ABS": return Math.Abs(Num(a[0]));
            case "INT": return Math.Floor(Num(a[0]));
            case "SQR":
                {
                    double x = Num(a[0]);
                    if (x < 0) throw Illegal();
                    return Math.Sqrt(x);
                }
            case "SIN": return Math.Sin(Num(a[0]));
            case "COS": return Math.Cos(Num(a[0]));
            case "TAN": return Math.Tan(Num(a[0]));
            case "ATN": return Math.Atan(Num(a[0]));
            case "LOG":
                {
                    double x = Num(a[0]);
                    if (x <= 0) throw Illegal();
                    return Math.Log(x);
                }
            case "EXP": return Math.Exp(Num(a[0]));
            case "SGN": return (double)Math.Sign(Num(a[0]));
            case "RND":
                {
                    double x = Num(a[0]);
                    if (x < 0) rnd = new Random((int)x);
                    return rnd.NextDouble();
                }
            case "LEN": return (double)Str(a[0]).Length;
            case "VAL": return ParseVal(Str(a[0]));
            case "ASC":
                {
                    string s = Str(a[0]);
                    if (s.Length == 0) throw Illegal();
                    return (double)(int)s[0];
                }
            case "CHR$":
                {
                    int n = (int)Num(a[0]);
                    if (n < 0 || n > 255) throw Illegal();
                    if (n == 13) return "\n";
                    return ((char)n).ToString();
                }
            case "STR$": return FmtCore(Num(a[0]));
            case "LEFT$":
                {
                    if (a.Count < 2) throw Syn();
                    string s = Str(a[0]);
                    int n = (int)Num(a[1]);
                    if (n < 0) throw Illegal();
                    return s.Substring(0, Math.Min(n, s.Length));
                }
            case "RIGHT$":
                {
                    if (a.Count < 2) throw Syn();
                    string s = Str(a[0]);
                    int n = (int)Num(a[1]);
                    if (n < 0) throw Illegal();
                    n = Math.Min(n, s.Length);
                    return s.Substring(s.Length - n);
                }
            case "MID$":
                {
                    if (a.Count < 2) throw Syn();
                    string s = Str(a[0]);
                    int st = (int)Num(a[1]);
                    if (st < 1) throw Illegal();
                    if (st > s.Length) return "";
                    int n = a.Count > 2 ? (int)Num(a[2]) : s.Length;
                    if (n < 0) throw Illegal();
                    n = Math.Min(n, s.Length - (st - 1));
                    return s.Substring(st - 1, n);
                }
            case "PEEK":
                {
                    int ad = (int)Num(a[0]);
                    if (ad < 0 || ad > 65535) throw Illegal();
                    return (double)Mem[ad];
                }
            case "FRE": return 38911.0;
            case "POS": return (double)Col;
        }
        throw Syn();
    }

    // ---------- arrays ----------
    private ArrData MakeArray(string id, int[] dims)
    {
        long total = 1;
        foreach (int d in dims)
        {
            if (d < 1) throw new BasicError("BAD SUBSCRIPT");
            total *= d;
            if (total > 1000000) throw new BasicError("OUT OF MEMORY");
        }
        ArrData a = new ArrData();
        a.Dims = dims;
        a.Data = new object[total];
        object def;
        if (id.EndsWith("$")) def = ""; else def = 0.0;
        for (int i = 0; i < a.Data.Length; i++) a.Data[i] = def;
        arrays[id] = a;
        return a;
    }

    private ArrData GetArrayData(string id, int nsubs)
    {
        ArrData a;
        if (!arrays.TryGetValue(id, out a))
        {
            int[] d = new int[nsubs];
            for (int i = 0; i < nsubs; i++) d[i] = 11;
            a = MakeArray(id, d);
        }
        if (a.Dims.Length != nsubs) throw new BasicError("BAD SUBSCRIPT");
        return a;
    }

    private int ArrIndex(ArrData a, List<object> subs)
    {
        int idx = 0;
        for (int i = 0; i < subs.Count; i++)
        {
            int s = (int)Num(subs[i]);
            if (s < 0 || s >= a.Dims[i]) throw new BasicError("BAD SUBSCRIPT");
            idx = idx * a.Dims[i] + s;
        }
        return idx;
    }

    // ---------- statements ----------
    private void ExecText(string t)
    {
        t = t.Trim();
        if (t.Length == 0) return;
        if (t[0] == '?') { src = t.Substring(1); p = 0; DoPrint(); return; }
        foreach (string k in Kw)
        {
            if (!t.StartsWith(k, StringComparison.Ordinal)) continue;
            src = t.Substring(k.Length);
            p = 0;
            switch (k)
            {
                case "PRINT": DoPrint(); break;
                case "INPUT": DoInput(); break;
                case "GOSUB": DoGosub(); break;
                case "GOTO": DoGoto(); break;
                case "RETURN": DoReturn(); break;
                case "RESTORE": dataPtr = 0; break;
                case "READ": DoRead(); break;
                case "DATA": break;
                case "REM": break;
                case "FOR": DoFor(); break;
                case "NEXT": DoNext(); break;
                case "END": State = BasState.Ended; break;
                case "STOP": Break(); break;
                case "DIM": DoDim(); break;
                case "POKE": DoPoke(); break;
                case "SYS": DoSys(); break;
                case "LET": DoAssign(); break;
                case "IF": DoIf(); break;
                case "CLR": ClearVars(); break;
                case "CMD": DoCmd(); break;
            }
            return;
        }
        src = t;
        p = 0;
        DoAssign();
    }

    private void DoCmd()
    {
        string s = Str(ParseExpr());
        if (HostCmd == null) throw new BasicError("UNDEF'D STATEMENT");
        if (Col != 0) W("\n");
        Flush();
        string err;
        try { err = HostCmd(s); }
        catch (BasicError) { throw; }
        catch (Exception ex) { err = ex.GetBaseException().Message.ToUpperInvariant(); }
        Col = 0;
        if (!String.IsNullOrEmpty(err)) throw new BasicError(err);
    }

    private void DoPrint()
    {
        bool nl = true;
        while (!AtEnd())
        {
            char c = Pk();
            if (c == ';') { p++; nl = false; continue; }
            if (c == ',')
            {
                p++;
                nl = false;
                int zone = ((Col / 10) + 1) * 10;
                W(new string(' ', zone - Col));
                continue;
            }
            if (AccWord("TAB"))
            {
                if (!Acc('(')) throw Syn();
                int n = (int)Num(ParseExpr());
                if (!Acc(')')) throw Syn();
                if (n > Col) W(new string(' ', n - Col));
                nl = true;
                continue;
            }
            if (AccWord("SPC"))
            {
                if (!Acc('(')) throw Syn();
                int n = (int)Num(ParseExpr());
                if (!Acc(')')) throw Syn();
                if (n > 0) W(new string(' ', n));
                nl = true;
                continue;
            }
            object v = ParseExpr();
            if (v is string) W((string)v);
            else W(FmtCore((double)v) + " ");
            nl = true;
        }
        if (nl) W("\n");
    }

    private void DoInput()
    {
        string prompt = "";
        if (Pk() == '"')
        {
            prompt = Str(ParsePrimary());
            Acc(';');
        }
        List<string> names = new List<string>();
        do
        {
            string id = ReadIdent();
            if (id.Length == 0) throw Syn();
            names.Add(id);
        } while (Acc(','));
        inputNames = names;
        inputBuf.Clear();
        W(prompt + "? ");
        State = BasState.Input;
    }

    private void JumpTo(int n)
    {
        int i;
        if (!lineIdx.TryGetValue(n, out i)) throw new BasicError("UNDEF'D STATEMENT");
        li = i;
        si = 0;
        jumped = true;
    }

    private void DoGoto() { JumpTo((int)Num(ParseExpr())); }

    private void DoGosub()
    {
        int n = (int)Num(ParseExpr());
        gosubs.Push(new int[] { li, si + 1 });
        JumpTo(n);
    }

    private void DoReturn()
    {
        if (gosubs.Count == 0) throw new BasicError("RETURN WITHOUT GOSUB");
        int[] r = gosubs.Pop();
        li = r[0];
        si = r[1];
        jumped = true;
    }

    private void DoFor()
    {
        string id = ReadIdent();
        if (id.Length == 0 || !Acc('=')) throw Syn();
        double start = Num(ParseExpr());
        if (!AccWord("TO")) throw Syn();
        double lim = Num(ParseExpr());
        double step = 1;
        if (AccWord("STEP")) step = Num(ParseExpr());
        vars[id] = start;
        fors.RemoveAll(f => f.Var == id);
        ForFrame fr = new ForFrame();
        fr.Var = id; fr.Limit = lim; fr.Step = step; fr.Li = li; fr.Si = si + 1;
        fors.Add(fr);
    }

    private void DoNext()
    {
        string id = null;
        if (!AtEnd()) id = ReadIdent();
        if (fors.Count == 0) throw new BasicError("NEXT WITHOUT FOR");
        int idx = fors.Count - 1;
        if (!String.IsNullOrEmpty(id))
        {
            string wanted = id;
            idx = fors.FindLastIndex(f => f.Var == wanted);
            if (idx < 0) throw new BasicError("NEXT WITHOUT FOR");
            fors.RemoveRange(idx + 1, fors.Count - idx - 1);
        }
        ForFrame fr = fors[idx];
        double v = Num(GetVar(fr.Var)) + fr.Step;
        vars[fr.Var] = v;
        bool cont = fr.Step >= 0 ? v <= fr.Limit : v >= fr.Limit;
        if (cont) { li = fr.Li; si = fr.Si; jumped = true; }
        else fors.RemoveAt(idx);
    }

    private void DoIf()
    {
        object c = ParseExpr();
        if (!AccWord("THEN") && !AccWord("GOTO")) throw Syn();
        bool truth = (c is string) ? ((string)c).Length > 0 : Num(c) != 0;
        if (!truth)
        {
            si = stmts[li].Count;
            jumped = true;
            return;
        }
        Ws();
        string rest = src.Substring(p).Trim();
        if (rest.Length > 0 && Char.IsDigit(rest[0]))
        {
            src = rest;
            p = 0;
            JumpTo((int)Num(ParseExpr()));
        }
        else ExecText(rest);
    }

    private void DoDim()
    {
        do
        {
            string id = ReadIdent();
            if (id.Length == 0 || !Acc('(')) throw Syn();
            List<int> dims = new List<int>();
            do { dims.Add((int)Num(ParseExpr()) + 1); } while (Acc(','));
            if (!Acc(')')) throw Syn();
            MakeArray(id, dims.ToArray());
        } while (Acc(','));
    }

    private void DoPoke()
    {
        int a = (int)Num(ParseExpr());
        if (!Acc(',')) throw Syn();
        int v = (int)Num(ParseExpr());
        if (a < 0 || a > 65535 || v < 0 || v > 255) throw Illegal();
        Mem[a] = (byte)v;
        if (OnPoke != null) OnPoke(a, v);
    }

    private void DoSys()
    {
        int a = (int)Num(ParseExpr());
        if (a == 64738 && OnReset != null)
        {
            Flush();
            OnReset();
        }
    }

    private void DoRead()
    {
        do
        {
            string id = ReadIdent();
            if (id.Length == 0) throw Syn();
            if (dataPtr >= dataItems.Count) throw new BasicError("OUT OF DATA");
            object item = dataItems[dataPtr++];
            if (id.EndsWith("$"))
            {
                if (item is string) vars[id] = item;
                else vars[id] = FmtCore((double)item).Trim();
            }
            else
            {
                if (!(item is double)) throw TypeMis();
                vars[id] = item;
            }
        } while (Acc(','));
    }

    private void DoAssign()
    {
        string id = ReadIdent();
        if (id.Length == 0) throw Syn();
        List<object> subs = null;
        if (Pk() == '(')
        {
            p++;
            subs = new List<object>();
            do { subs.Add(ParseExpr()); } while (Acc(','));
            if (!Acc(')')) throw Syn();
        }
        if (!Acc('=')) throw Syn();
        object v = ParseExpr();
        bool isStr = id.EndsWith("$");
        if (isStr != (v is string)) throw TypeMis();
        if (subs == null) vars[id] = v;
        else
        {
            ArrData a = GetArrayData(id, subs.Count);
            a.Data[ArrIndex(a, subs)] = v;
        }
    }
}
'@
if (-not ('Slicer' -as [type])) { Add-Type -TypeDefinition $csharp -Language CSharp }

# ---------------------------------------------------------------------
#  Theme
# ---------------------------------------------------------------------
$theme = @{
    Background = [System.Drawing.Color]::FromArgb(20, 20, 30)
    Panel      = [System.Drawing.Color]::FromArgb(30, 30, 44)
    Foreground = [System.Drawing.Color]::FromArgb(230, 230, 255)
    AccentNeon = [System.Drawing.Color]::FromArgb(0, 255, 255)
    AccentPink = [System.Drawing.Color]::FromArgb(255, 50, 150)
    AccentRed  = [System.Drawing.Color]::FromArgb(255, 100, 100)
    Highlight  = [System.Drawing.Color]::FromArgb(70, 70, 90)
    Font       = New-Object System.Drawing.Font('Consolas', 9)
    FontBold   = New-Object System.Drawing.Font('Consolas', 10, [System.Drawing.FontStyle]::Bold)
    FontTerm   = New-Object System.Drawing.Font('Consolas', 11, [System.Drawing.FontStyle]::Bold)
}

# Commodore 64 palette (Pepto), index 0-15
$c64Pal = @(
    [System.Drawing.Color]::FromArgb(0, 0, 0),       [System.Drawing.Color]::FromArgb(255, 255, 255),
    [System.Drawing.Color]::FromArgb(136, 57, 50),   [System.Drawing.Color]::FromArgb(103, 182, 189),
    [System.Drawing.Color]::FromArgb(139, 63, 150),  [System.Drawing.Color]::FromArgb(85, 160, 73),
    [System.Drawing.Color]::FromArgb(64, 49, 141),   [System.Drawing.Color]::FromArgb(191, 206, 114),
    [System.Drawing.Color]::FromArgb(139, 84, 41),   [System.Drawing.Color]::FromArgb(87, 66, 0),
    [System.Drawing.Color]::FromArgb(184, 105, 98),  [System.Drawing.Color]::FromArgb(80, 80, 80),
    [System.Drawing.Color]::FromArgb(120, 120, 120), [System.Drawing.Color]::FromArgb(148, 224, 137),
    [System.Drawing.Color]::FromArgb(120, 105, 196), [System.Drawing.Color]::FromArgb(159, 159, 159)
)
# PETSCII colour-code characters -> palette index (PRINT CHR$(28) etc.)
$script:PetColors = @{ 144 = 0; 5 = 1; 28 = 2; 159 = 3; 156 = 4; 30 = 5; 31 = 6; 158 = 7;
                       129 = 8; 149 = 9; 150 = 10; 151 = 11; 152 = 12; 153 = 13; 154 = 14; 155 = 15 }

# ---------------------------------------------------------------------
#  Global state
# ---------------------------------------------------------------------
$script:Results      = New-Object System.Collections.ArrayList
$script:SortCol      = 0
$script:SortAsc      = $false
$script:DisplayLimit = 25000
$script:Busy         = $false
$script:ActiveSlicer = $null
$script:TermList     = @()
$script:Ranked       = @()
$script:Aliases      = @{}
if ($PSScriptRoot) { $script:ProgDir = Join-Path $PSScriptRoot 'Programs' } else { $script:ProgDir = Join-Path $env:APPDATA 'FileSlicer64\Programs' }
$script:History      = New-Object System.Collections.ArrayList
$script:HistIdx      = 0
$script:ListMode     = 'prog'
$script:DirLines     = @()
$script:SkipReady    = $false
$script:TermFg       = $c64Pal[14]
$script:TermBuf      = New-Object System.Text.StringBuilder
try { $script:Cwd = (Get-Location).ProviderPath } catch { $script:Cwd = $env:USERPROFILE }
if (-not (Test-Path -LiteralPath $script:Cwd -PathType Container)) { $script:Cwd = $env:USERPROFILE }

# ---------------------------------------------------------------------
#  Small helpers
# ---------------------------------------------------------------------
function Format-Size([long]$Bytes) {
    if ($Bytes -ge 1GB) { return ('{0:N2} GB' -f ($Bytes / 1GB)) }
    if ($Bytes -ge 1MB) { return ('{0:N2} MB' -f ($Bytes / 1MB)) }
    if ($Bytes -ge 1KB) { return ('{0:N1} KB' -f ($Bytes / 1KB)) }
    return ('{0} B' -f $Bytes)
}

function ConvertTo-ExtList([string]$Text) {
    $out = @()
    foreach ($tok in ($Text -split '[,;\s]+')) {
        $t = $tok.Trim()
        if ($t -eq '') { continue }
        if ($t -eq '*' -or $t -eq '*.*') { return @() }
        $t = $t.TrimStart('*').TrimStart('.').ToLower()
        if ($t -ne '') { $out += ('.' + $t) }
    }
    return $out
}

function ConvertTo-WildRegex([string]$Pattern) {
    if ([string]::IsNullOrEmpty($Pattern) -or $Pattern -eq '*') { return '^.*$' }
    $body = [regex]::Escape($Pattern) -replace '\\\*', '.*' -replace '\\\?', '.'
    return '^' + $body + '$'
}

# ---------------------------------------------------------------------
#  Main form + layout
# ---------------------------------------------------------------------
$form = New-Object System.Windows.Forms.Form
$form.Text = '💻 斬る File Slicer (ファイル・スライサー) 💻 v16'
$form.Size = New-Object System.Drawing.Size(1150, 830)
$form.MinimumSize = New-Object System.Drawing.Size(980, 680)
$form.StartPosition = 'CenterScreen'
$form.BackColor = $theme.Background
$form.ForeColor = $theme.Foreground
$form.Font = $theme.Font
$form.KeyPreview = $true

$tip = New-Object System.Windows.Forms.ToolTip
$tip.InitialDelay = 250
$tip.AutoPopDelay = 12000
$tip.ShowAlways = $true

$inputPanel = New-Object System.Windows.Forms.Panel
$inputPanel.Dock = 'Top'
$inputPanel.Height = 212
$inputPanel.BackColor = $theme.Background

$statusPanel = New-Object System.Windows.Forms.Panel
$statusPanel.Dock = 'Bottom'
$statusPanel.Height = 30
$statusPanel.BackColor = $theme.Background

$txtStatus = New-Object System.Windows.Forms.TextBox
$txtStatus.Dock = 'Fill'
$txtStatus.ReadOnly = $true
$txtStatus.BackColor = $theme.Background
$txtStatus.ForeColor = $theme.AccentNeon
$txtStatus.Font = $theme.Font
$txtStatus.BorderStyle = 'None'
$txtStatus.Text = '準備完了 (Ready)... 🍣   F5 = Slice   F2 = C64 Terminal   F1 = Manual   Esc = Stop'
$statusPanel.Controls.Add($txtStatus)

$split = New-Object System.Windows.Forms.SplitContainer
$split.Dock = 'Fill'
$split.Orientation = 'Horizontal'
$split.SplitterWidth = 6
$split.BackColor = $theme.Highlight

# ---- results list ----------------------------------------------------
$lv = New-Object System.Windows.Forms.ListView
$lv.Dock = 'Fill'
$lv.View = 'Details'
$lv.FullRowSelect = $true
$lv.MultiSelect = $true
$lv.HideSelection = $false
$lv.BorderStyle = 'FixedSingle'
$lv.BackColor = [System.Drawing.Color]::FromArgb(40, 40, 50)
$lv.ForeColor = $theme.Foreground
$lv.Font = $theme.Font
$lv.AllowDrop = $true
try {
    $dbp = $lv.GetType().GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]'Instance,NonPublic')
    $dbp.SetValue($lv, $true, $null)
} catch { }
$right = [System.Windows.Forms.HorizontalAlignment]::Right
$left  = [System.Windows.Forms.HorizontalAlignment]::Left
[void]$lv.Columns.Add('サイズ (Size)', 105, $right)
[void]$lv.Columns.Add('更新日時 (Modified)', 140, $left)
[void]$lv.Columns.Add('種類 (Type)', 70, $left)
[void]$lv.Columns.Add('名前 (Name)', 270, $left)
[void]$lv.Columns.Add('フォルダ (Folder)', 520, $left)
[void]$lv.Columns.Add('備考 (Note)', 90, $left)
$split.Panel1.Controls.Add($lv)

# ---- C64 terminal ----------------------------------------------------
$termPanel = New-Object System.Windows.Forms.Panel
$termPanel.Dock = 'Fill'
$termPanel.Padding = New-Object System.Windows.Forms.Padding(26, 18, 26, 18)
$termPanel.BackColor = $c64Pal[14]

$termOut = New-Object System.Windows.Forms.RichTextBox
$termOut.Dock = 'Fill'
$termOut.ReadOnly = $true
$termOut.BorderStyle = 'None'
$termOut.BackColor = $c64Pal[6]
$termOut.ForeColor = $c64Pal[14]
$termOut.Font = $theme.FontTerm
$termOut.WordWrap = $true
$termOut.ScrollBars = 'Vertical'
$termOut.HideSelection = $false
$termOut.TabStop = $false
$termOut.Cursor = [System.Windows.Forms.Cursors]::IBeam

$termIn = New-Object System.Windows.Forms.TextBox
$termIn.Dock = 'Bottom'
$termIn.BorderStyle = 'None'
$termIn.BackColor = $c64Pal[6]
$termIn.ForeColor = [System.Drawing.Color]::White
$termIn.Font = $theme.FontTerm

$termPanel.Controls.Add($termOut)
$termPanel.Controls.Add($termIn)
$split.Panel2.Controls.Add($termPanel)

$form.Controls.Add($split)
$form.Controls.Add($inputPanel)
$form.Controls.Add($statusPanel)

# ---- input panel -----------------------------------------------------
$PaddingLeft = 20
$ButtonWidth = 160

$lblPath = New-Object System.Windows.Forms.Label
$lblPath.Text = '対象フォルダ (Target Folder):'
$lblPath.Location = New-Object System.Drawing.Point($PaddingLeft, 10)
$lblPath.AutoSize = $true
$lblPath.ForeColor = $theme.AccentNeon
$inputPanel.Controls.Add($lblPath)

$txtPath = New-Object System.Windows.Forms.TextBox
$txtPath.Location = New-Object System.Drawing.Point($PaddingLeft, 32)
$txtPath.Width = 700
$txtPath.BorderStyle = 'FixedSingle'
$txtPath.BackColor = $theme.Background
$txtPath.ForeColor = $theme.AccentNeon
$txtPath.Anchor = 'Top, Left, Right'
$txtPath.AllowDrop = $true
$inputPanel.Controls.Add($txtPath)

$btnBrowse = New-Object System.Windows.Forms.Button
$btnBrowse.Text = '参照 (Browse)...'
$btnBrowse.Size = New-Object System.Drawing.Size($ButtonWidth, 26)
$btnBrowse.FlatStyle = 'Flat'
$btnBrowse.FlatAppearance.BorderSize = 0
$btnBrowse.BackColor = $theme.AccentPink
$btnBrowse.ForeColor = $theme.Background
$btnBrowse.Anchor = 'Top, Right'
$inputPanel.Controls.Add($btnBrowse)

$filterPanel = New-Object System.Windows.Forms.FlowLayoutPanel
$filterPanel.Location = New-Object System.Drawing.Point($PaddingLeft, 66)
$filterPanel.Height = 92
$filterPanel.Width = 1000
$filterPanel.FlowDirection = 'LeftToRight'
$filterPanel.WrapContents = $true
$filterPanel.Anchor = 'Top, Left, Right'
$inputPanel.Controls.Add($filterPanel)

$labelMargin = New-Object System.Windows.Forms.Padding(0, 8, 3, 0)
$boxMargin   = New-Object System.Windows.Forms.Padding(0, 5, 12, 0)

function Add-FilterLabel([string]$Text, $Color) {
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $Text
    $l.AutoSize = $true
    $l.ForeColor = $Color
    $l.Margin = $labelMargin
    $filterPanel.Controls.Add($l)
    return $l
}
function Add-FilterBox([int]$Width, $Color) {
    $t = New-Object System.Windows.Forms.TextBox
    $t.Width = $Width
    $t.BorderStyle = 'FixedSingle'
    $t.Margin = $boxMargin
    $t.BackColor = $theme.Background
    $t.ForeColor = $Color
    $filterPanel.Controls.Add($t)
    return $t
}
function Add-FilterCheck([string]$Text, $Color) {
    $c = New-Object System.Windows.Forms.CheckBox
    $c.Text = $Text
    $c.AutoSize = $true
    $c.ForeColor = $Color
    $c.Margin = $labelMargin
    $filterPanel.Controls.Add($c)
    return $c
}
function Add-FilterCombo([int]$Width, [string[]]$Items) {
    $cb = New-Object System.Windows.Forms.ComboBox
    $cb.DropDownStyle = 'DropDownList'
    $cb.Width = $Width
    $cb.Margin = $boxMargin
    $cb.FlatStyle = 'Flat'
    $cb.BackColor = $theme.Background
    $cb.ForeColor = $theme.AccentNeon
    foreach ($i in $Items) { [void]$cb.Items.Add($i) }
    $cb.SelectedIndex = 0
    $filterPanel.Controls.Add($cb)
    return $cb
}

# row 1: file types / preset / name / regex / content
$lblTypes  = Add-FilterLabel '種類 (File Types):' $theme.AccentNeon
$txtTypes  = Add-FilterBox 150 $theme.AccentNeon
$txtTypes.Text = '*'
$cboPreset = Add-FilterCombo 190 @(
    'プリセット (Preset)...',
    'すべて (All Files) *',
    '音声 (Audio)',
    '動画 (Video)',
    '画像 (Images)',
    '文書 (Documents)',
    '圧縮 (Archives)',
    'コード (Code)',
    'DAW / FL Studio',
    'プラグイン (Plugins)',
    'コモドール (Commodore 64)')
$lblName   = Add-FilterLabel '名前 (Name):' $theme.AccentNeon
$txtName   = Add-FilterBox 150 $theme.AccentNeon
$chkRegex  = Add-FilterCheck '正規表現 (Regex)' $theme.AccentNeon
$lblText   = Add-FilterLabel '内容 (Contains Text):' $theme.AccentPink
$txtText   = Add-FilterBox 150 $theme.AccentPink

# row 2: size / date / options
$lblSizeMin = Add-FilterLabel '最小 (Min MB):' $theme.AccentPink
$txtSizeMin = Add-FilterBox 70 $theme.AccentPink
$lblSizeMax = Add-FilterLabel '最大 (Max MB):' $theme.AccentPink
$txtSizeMax = Add-FilterBox 70 $theme.AccentPink
$chkEnableDate = Add-FilterCheck '日付 (Date):' $theme.AccentNeon
$cboDate = Add-FilterCombo 150 @('以降 (Newer than)', '以前 (Older than)')
$cboDate.Enabled = $false
$dtpDate = New-Object System.Windows.Forms.DateTimePicker
$dtpDate.Format = [System.Windows.Forms.DateTimePickerFormat]::Custom
$dtpDate.CustomFormat = 'yyyy-MM-dd'
$dtpDate.Size = New-Object System.Drawing.Size(115, 25)
$dtpDate.Margin = $boxMargin
$dtpDate.Enabled = $false
$dtpDate.CalendarTitleBackColor = $theme.Background
$dtpDate.CalendarTitleForeColor = $theme.AccentNeon
$filterPanel.Controls.Add($dtpDate)
$chkSub = Add-FilterCheck 'サブフォルダ (Subfolders)' $theme.AccentNeon
$chkSub.Checked = $true
$chkHidden = Add-FilterCheck '隠しファイル (Hidden)' $theme.AccentNeon
$chkHidden.Checked = $true

$chkEnableDate.Add_Click({
    $dtpDate.Enabled = $chkEnableDate.Checked
    $cboDate.Enabled = $chkEnableDate.Checked
})

# ---- button bar --------------------------------------------------------
$btnBar = New-Object System.Windows.Forms.FlowLayoutPanel
$btnBar.Location = New-Object System.Drawing.Point($PaddingLeft, 164)
$btnBar.Height = 38
$btnBar.Width = 1000
$btnBar.FlowDirection = 'LeftToRight'
$btnBar.WrapContents = $false
$btnBar.Anchor = 'Top, Left, Right'
$inputPanel.Controls.Add($btnBar)

function Add-BarButton([string]$Text, $Back, $Fore, [bool]$Bold) {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $Text
    $b.AutoSize = $true
    $b.AutoSizeMode = 'GrowAndShrink'
    $b.MinimumSize = New-Object System.Drawing.Size(110, 30)
    $b.FlatStyle = 'Flat'
    $b.FlatAppearance.BorderSize = 0
    $b.BackColor = $Back
    $b.ForeColor = $Fore
    $b.Margin = New-Object System.Windows.Forms.Padding(0, 3, 8, 3)
    if ($Bold) { $b.Font = $theme.FontBold }
    $btnBar.Controls.Add($b)
    return $b
}
$btnSearch = Add-BarButton '切断 (Slice) ❖' $theme.AccentNeon $theme.Background $true
$btnStop   = Add-BarButton '中止 (Stop)' $theme.AccentRed $theme.Background $false
$btnStop.Enabled = $false
$btnDupes  = Add-BarButton '重複 (Find Dupes)' $theme.AccentPink $theme.Background $false
$btnStats  = Add-BarButton '統計 (Stats)' $theme.Highlight $theme.Foreground $false
$btnExport = Add-BarButton '出力 (Export CSV)' $theme.Highlight $theme.Foreground $false
$btnBas    = Add-BarButton 'プログラム (Run .bas) ▶' ([System.Drawing.Color]::FromArgb(64, 49, 141)) ([System.Drawing.Color]::White) $false
$btnTerm   = Add-BarButton '端末 (C64 Terminal)' ([System.Drawing.Color]::FromArgb(64, 49, 141)) ([System.Drawing.Color]::FromArgb(160, 150, 230)) $false

# ---- tooltips (English + 日本語) ---------------------------------------
$tip.SetToolTip($txtPath,    'Folder to search. You can also drag & drop a folder here.  検索するフォルダ (ドラッグ&ドロップ可)')
$tip.SetToolTip($btnBrowse,  'Choose the folder to slice.  フォルダを選択')
$tip.SetToolTip($txtTypes,   'File extensions, e.g.  wav mp3 flac   or   *   for all files.  拡張子 (* = すべて)')
$tip.SetToolTip($cboPreset,  'Quick presets for common file types.  よく使う種類のプリセット')
$tip.SetToolTip($txtName,    'File name filter. Wildcards * ? allowed; plain text = "contains".  ファイル名フィルタ')
$tip.SetToolTip($chkRegex,   'Treat the name filter as a regular expression.  名前を正規表現として扱う')
$tip.SetToolTip($txtText,    'Only files whose contents include this text (ASCII/UTF-8, files up to 64 MB).  ファイル内テキスト検索')
$tip.SetToolTip($txtSizeMin, 'Minimum file size in megabytes (decimals ok).  最小サイズ (MB)')
$tip.SetToolTip($txtSizeMax, 'Maximum file size in megabytes (decimals ok).  最大サイズ (MB)')
$tip.SetToolTip($chkEnableDate, 'Enable the modified-date filter.  更新日フィルタを有効化')
$tip.SetToolTip($cboDate,    'Newer than = modified on/after the date. Older than = before the date.  以降 / 以前')
$tip.SetToolTip($chkSub,     'Search inside subfolders too.  サブフォルダも検索')
$tip.SetToolTip($chkHidden,  'Include hidden files.  隠しファイルを含める')
$tip.SetToolTip($btnSearch,  'Run the search (F5).  検索開始')
$tip.SetToolTip($btnStop,    'Stop the running search (Esc).  検索を中止')
$tip.SetToolTip($btnDupes,   'Find duplicate files using the current filters (size, then hash).  重複ファイルを検索')
$tip.SetToolTip($btnStats,   'Show statistics of the current results in the terminal.  結果の統計を表示')
$tip.SetToolTip($btnExport,  'Save the current results to a CSV file.  結果をCSVに保存')
$tip.SetToolTip($btnBas,    'Pick a BASIC .bas program with a file dialog and run it in the C64 terminal (same as RUN ?).  BASICプログラムを選んで実行')
$tip.SetToolTip($btnTerm,    'Show / hide the Commodore-64 style terminal (F2).  C64端末の表示切替')
$tip.SetToolTip($lv,         'Click column headers to sort. Double-click opens a file. Right-click for more.  ヘッダーでソート / 右クリックメニュー')

function Update-Layout {
    $w = $inputPanel.ClientSize.Width
    $btnBrowse.Location = New-Object System.Drawing.Point(($w - $ButtonWidth - $PaddingLeft), 30)
    $txtPath.Width = $btnBrowse.Left - $PaddingLeft - 12
    $filterPanel.Width = $w - (2 * $PaddingLeft)
    $btnBar.Width = $w - (2 * $PaddingLeft)
}
$inputPanel.Add_Resize({ Update-Layout })

# ---------------------------------------------------------------------
#  Scanner glue
# ---------------------------------------------------------------------
function Set-BusyState([bool]$Busy) {
    $script:Busy = $Busy
    $btnSearch.Enabled = -not $Busy
    $btnDupes.Enabled  = -not $Busy
    $btnBrowse.Enabled = -not $Busy
    $btnStop.Enabled   = $Busy
}

function Invoke-Slicer($Options) {
    $sl = New-Object Slicer
    $script:ActiveSlicer = $sl
    Set-BusyState $true
    $spin = @('|', '/', '-', '\')
    $i = 0
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $sl.Start($Options)
    while (-not $sl.Done) {
        [System.Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 35
        $i++
        if ($i % 3 -eq 0) {
            $where = $sl.CurrentDir
            if ($where.Length -gt 70) { $where = '...' + $where.Substring($where.Length - 67) }
            $txtStatus.Text = ('{0} 切断中 (Slicing)  スキャン (Scanned): {1:N0}  一致 (Matched): {2:N0}  [{3}]  {4}' -f `
                $spin[($i / 3) % 4], $sl.Scanned, $sl.Matched, $sl.Phase, $where)
        }
    }
    $sw.Stop()
    $script:LastElapsed = $sw.Elapsed.TotalSeconds
    $script:ActiveSlicer = $null
    Set-BusyState $false
    if ($sl.Error) { $txtStatus.Text = '❌ エラー (Error): ' + $sl.Error }
    return $sl
}

function Get-RowColor([long]$Bytes) {
    $mb = $Bytes / 1MB
    if ($mb -ge 1024) { return $theme.AccentRed }
    if ($mb -ge 500)  { return $theme.AccentPink }
    return $theme.AccentNeon
}

function Show-Results {
    $arr = @($script:Results)
    $props = @('Length', 'Modified', 'Ext', 'Name', 'Dir', 'Extra')
    if ($arr.Count -gt 1) {
        $arr = @($arr | Sort-Object -Property $props[$script:SortCol] -Descending:(-not $script:SortAsc))
    }
    $script:Ranked = $arr
    $rows = New-Object 'System.Collections.Generic.List[System.Windows.Forms.ListViewItem]'
    $n = 0
    $total = 0L
    foreach ($h in $arr) {
        $total += $h.Length
        if ($n -lt $script:DisplayLimit) {
            $it = New-Object System.Windows.Forms.ListViewItem((Format-Size $h.Length))
            [void]$it.SubItems.Add($h.Modified.ToString('yyyy/MM/dd HH:mm'))
            [void]$it.SubItems.Add($h.Ext)
            [void]$it.SubItems.Add($h.Name)
            [void]$it.SubItems.Add($h.Dir)
            [void]$it.SubItems.Add($h.Extra)
            $it.Tag = $h
            $it.ForeColor = Get-RowColor $h.Length
            $rows.Add($it)
            $n++
        }
    }
    $lv.BeginUpdate()
    try {
        $lv.Items.Clear()
        $lv.Items.AddRange($rows.ToArray())
    } finally { $lv.EndUpdate() }
    $script:ShownTotal = $total
    $script:ShownCount = $arr.Count
}

function Set-Results($Hits) {
    $script:Results.Clear()
    if ($Hits -and @($Hits).Count -gt 0) { $script:Results.AddRange([object[]]@($Hits)) }
    Show-Results
}

function Get-SelectedHits {
    return @($lv.SelectedItems | ForEach-Object { $_.Tag })
}

function Get-GuiOptions {
    $path = $txtPath.Text.Trim().Trim('"')
    if (-not $path -or -not (Test-Path -LiteralPath $path -PathType Container)) {
        [void][System.Windows.Forms.MessageBox]::Show($form,
            "対象パスが無効です。`n(The target folder is invalid.)",
            'Error: Invalid Path', 'OK', 'Error')
        return $null
    }
    $o = New-Object SliceOptions
    $o.Root = $path
    $o.Extensions = [string[]]@(ConvertTo-ExtList $txtTypes.Text)
    $o.NamePattern = $txtName.Text.Trim()
    $o.UseRegex = $chkRegex.Checked
    $o.ContentText = $txtText.Text
    $o.Recurse = $chkSub.Checked
    $o.IncludeHidden = $chkHidden.Checked
    $min = $txtSizeMin.Text.Trim()
    $max = $txtSizeMax.Text.Trim()
    if ($min -match '^\d+(\.\d+)?$') { $o.MinBytes = [int64]([double]$min * 1MB) }
    if ($max -match '^\d+(\.\d+)?$') { $o.MaxBytes = [int64]([double]$max * 1MB) }
    if ($chkEnableDate.Checked) {
        $o.UseDate = $true
        $o.DateValue = $dtpDate.Value.Date
        $o.DateNewer = ($cboDate.SelectedIndex -eq 0)
    }
    if ($o.NamePattern -and $o.UseRegex) {
        try { [void][regex]::new($o.NamePattern) } catch {
            [void][System.Windows.Forms.MessageBox]::Show($form,
                "正規表現が無効です。`n(Invalid regular expression.)`n`n" + $_.Exception.Message, 'Regex Error', 'OK', 'Warning')
            return $null
        }
    }
    return $o
}

function Start-GuiSearch([bool]$Dupes) {
    if ($script:Busy) { return }
    if ($basic.State.ToString() -eq 'Running') { $txtStatus.Text = '⚪ BASIC program running - press Esc in the terminal first.'; return }
    $o = Get-GuiOptions
    if ($null -eq $o) { return }
    $o.FindDupes = $Dupes
    $sl = Invoke-Slicer $o
    $hits = @($sl.Hits)
    if ($Dupes) { $script:SortCol = 5; $script:SortAsc = $true } else { $script:SortCol = 0; $script:SortAsc = $false }
    Set-Results $hits
    $secs = '{0:N1}' -f $script:LastElapsed
    $extra = ''
    if ($Dupes -and $hits.Count -gt 0) {
        $wasted = 0L
        foreach ($g in ($hits | Group-Object -Property Extra)) { $wasted += [int64]$g.Group[0].Length * ($g.Count - 1) }
        $extra = ' | 無駄 (Wasted): ' + (Format-Size $wasted)
    }
    $cut = ''
    if ($script:ShownCount -gt $script:DisplayLimit) { $cut = " (表示 shown: $($script:DisplayLimit))" }
    $stopped = ''
    if ($sl.Cancel) { $stopped = ' ⚪ 中止 (Stopped)' }
    if (-not $sl.Error) {
        $txtStatus.Text = ('検索完了 (Done). {0:N0} 件 (files){1} | 合計 (Total): {2}{3} | {4}s | スキャン (Scanned): {5:N0}{6} 🍱' -f `
            $hits.Count, $cut, (Format-Size $script:ShownTotal), $extra, $secs, $sl.Scanned, $stopped)
    }
}

# ---------------------------------------------------------------------
#  Context menu actions
# ---------------------------------------------------------------------
function Open-Selected {
    $h = Get-SelectedHits
    if ($h.Count -eq 0) { return }
    try { Start-Process -FilePath $h[0].FullName } catch { $txtStatus.Text = '❌ エラー (Error): ' + $_.Exception.Message }
}

function Show-InFolder {
    $h = Get-SelectedHits
    if ($h.Count -eq 0) { return }
    Start-Process -FilePath 'explorer.exe' -ArgumentList ('/select,"' + $h[0].FullName + '"')
}

function Copy-PathsToClipboard {
    $h = Get-SelectedHits
    if ($h.Count -eq 0) { return }
    [System.Windows.Forms.Clipboard]::SetText(($h | ForEach-Object { $_.FullName }) -join "`r`n")
    $txtStatus.Text = "📋 パスをコピー (Copied $($h.Count) path(s) to clipboard)"
}

function Copy-SelectedTo([bool]$Move) {
    $hits = Get-SelectedHits
    if ($hits.Count -eq 0) { return }
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    if ($Move) { $dlg.Description = '移動先 (Select destination folder for MOVE):' }
    else { $dlg.Description = 'コピー先 (Select destination folder for COPY):' }
    if ($dlg.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) {
        $txtStatus.Text = '⚪ キャンセル (Cancelled).'
        return
    }
    $ok = 0; $bad = 0; $lastErr = ''
    foreach ($h in $hits) {
        try {
            if ($Move) { Move-Item -LiteralPath $h.FullName -Destination $dlg.SelectedPath -Force -ErrorAction Stop }
            else { Copy-Item -LiteralPath $h.FullName -Destination $dlg.SelectedPath -Force -ErrorAction Stop }
            $ok++
            if ($Move) { $script:Results.Remove($h) }
        } catch { $bad++; $lastErr = $_.Exception.Message }
    }
    if ($Move) { Show-Results }
    if ($bad -eq 0) { $txtStatus.Text = "✅ 完了 (Done): $ok file(s) -> $($dlg.SelectedPath)" }
    else { $txtStatus.Text = "⚠️ $ok ok, $bad failed. $lastErr" }
}

function Remove-SelectedToRecycleBin {
    $hits = Get-SelectedHits
    if ($hits.Count -eq 0) { return }
    $msg = "選択した $($hits.Count) 個のファイルをごみ箱に送りますか?`n(Send $($hits.Count) file(s) to the Recycle Bin?)`n`n" +
           (($hits | Select-Object -First 8 | ForEach-Object { $_.FullName }) -join "`n")
    if ($hits.Count -gt 8) { $msg += "`n... +$($hits.Count - 8) more" }
    $r = [System.Windows.Forms.MessageBox]::Show($form, $msg, 'Confirm Delete (削除の確認)', 'YesNo', 'Warning')
    if ($r -ne [System.Windows.Forms.DialogResult]::Yes) { $txtStatus.Text = '⚪ キャンセル (Cancelled).'; return }
    $ok = 0; $bad = 0; $lastErr = ''
    foreach ($h in $hits) {
        try {
            [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile($h.FullName, 'OnlyErrorDialogs', 'SendToRecycleBin')
            $script:Results.Remove($h)
            $ok++
        } catch { $bad++; $lastErr = $_.Exception.Message }
    }
    Show-Results
    if ($bad -eq 0) { $txtStatus.Text = "✅ 削除完了 (Recycled): $ok file(s)." }
    else { $txtStatus.Text = "⚠️ $ok recycled, $bad failed. $lastErr" }
}

function Show-HashOfSelected {
    $h = Get-SelectedHits
    if ($h.Count -eq 0) { return }
    $txtStatus.Text = 'ハッシュ計算中 (Hashing)...'
    $form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor
    $form.Refresh()
    try {
        $r = Get-FileHash -LiteralPath $h[0].FullName -Algorithm SHA256 -ErrorAction Stop
        [System.Windows.Forms.Clipboard]::SetText($r.Hash)
        $txtStatus.Text = "SHA-256 $($h[0].Name): $($r.Hash)  (clipboard へコピー)"
    } catch { $txtStatus.Text = '❌ エラー (Error): ' + $_.Exception.Message }
    $form.Cursor = [System.Windows.Forms.Cursors]::Default
}

function Export-ResultsTo([string]$Path) {
    $script:Results | ForEach-Object {
        [pscustomobject]@{
            Path      = $_.FullName
            Name      = $_.Name
            Type      = $_.Ext
            SizeBytes = $_.Length
            SizeMB    = [math]::Round($_.Length / 1MB, 3)
            Modified  = $_.Modified.ToString('yyyy-MM-dd HH:mm:ss')
            Note      = $_.Extra
        }
    } | Export-Csv -LiteralPath $Path -NoTypeInformation -Encoding UTF8
}

function Export-ResultsDialog {
    if ($script:Results.Count -eq 0) { $txtStatus.Text = '⚪ 出力する結果がありません (Nothing to export).'; return }
    $dlg = New-Object System.Windows.Forms.SaveFileDialog
    $dlg.Filter = 'CSV (*.csv)|*.csv'
    $dlg.FileName = 'slice_results.csv'
    if ($dlg.ShowDialog($form) -eq [System.Windows.Forms.DialogResult]::OK) {
        try {
            Export-ResultsTo $dlg.FileName
            $txtStatus.Text = "✅ 出力完了 (Exported $($script:Results.Count) rows): $($dlg.FileName)"
        } catch { $txtStatus.Text = '❌ エラー (Error): ' + $_.Exception.Message }
    }
}

$ctx = New-Object System.Windows.Forms.ContextMenuStrip
$ctx.BackColor = $theme.Panel
$ctx.ForeColor = $theme.Foreground
function Add-MenuItem([string]$Text, [scriptblock]$Action) {
    $mi = New-Object System.Windows.Forms.ToolStripMenuItem($Text)
    $mi.Add_Click($Action)
    [void]$ctx.Items.Add($mi)
}
Add-MenuItem '開く (Open) 📂' { Open-Selected }
Add-MenuItem 'フォルダを表示 (Show in Folder)' { Show-InFolder }
Add-MenuItem 'パスをコピー (Copy Path) 📋' { Copy-PathsToClipboard }
[void]$ctx.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator))
Add-MenuItem 'コピー先... (Copy To...) 📁' { Copy-SelectedTo $false }
Add-MenuItem '移動先... (Move To...) ➡️' { Copy-SelectedTo $true }
Add-MenuItem 'SHA-256ハッシュ (Hash -> clipboard)' { Show-HashOfSelected }
[void]$ctx.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator))
Add-MenuItem 'ごみ箱へ (Move to Recycle Bin) 🗑️' { Remove-SelectedToRecycleBin }
$lv.ContextMenuStrip = $ctx
$ctx.Add_Opening({ param($s, $e) if ($lv.SelectedItems.Count -eq 0) { $e.Cancel = $true } })

$lv.Add_DoubleClick({ Open-Selected })
$lv.Add_KeyDown({
    param($s, $e)
    if ($e.KeyCode -eq 'Return') { Open-Selected; $e.SuppressKeyPress = $true }
    elseif ($e.KeyCode -eq 'Delete') { Remove-SelectedToRecycleBin }
    elseif ($e.Control -and $e.KeyCode -eq 'C') { Copy-PathsToClipboard; $e.SuppressKeyPress = $true }
    elseif ($e.Control -and $e.KeyCode -eq 'A') { foreach ($i in $lv.Items) { $i.Selected = $true } }
})
$lv.Add_ColumnClick({
    param($s, $e)
    if ($script:SortCol -eq $e.Column) { $script:SortAsc = -not $script:SortAsc }
    else { $script:SortCol = $e.Column; $script:SortAsc = ($e.Column -ge 2) }
    Show-Results
})

# ---------------------------------------------------------------------
#  Button + control events
# ---------------------------------------------------------------------
$btnBrowse.Add_Click({
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = '切るフォルダを選択 (Select the folder to slice)...'
    if ($dialog.ShowDialog($form) -eq [System.Windows.Forms.DialogResult]::OK) { $txtPath.Text = $dialog.SelectedPath }
})
$btnSearch.Add_Click({ Start-GuiSearch $false })
$btnDupes.Add_Click({ Start-GuiSearch $true })
$btnStop.Add_Click({ if ($script:ActiveSlicer) { $script:ActiveSlicer.Cancel = $true } })
$btnExport.Add_Click({ Export-ResultsDialog })
$btnStats.Add_Click({
    if ($split.Panel2Collapsed) { $split.Panel2Collapsed = $false }
    Submit-Term 'STATS'
})
$btnTerm.Add_Click({ Switch-Terminal })
$btnBas.Add_Click({
    if ($split.Panel2Collapsed) { $split.Panel2Collapsed = $false }
    Submit-Term 'RUN ?'
    $termIn.Focus()
})

$cboPreset.Add_SelectedIndexChanged({
    switch ($cboPreset.SelectedIndex) {
        1  { $txtTypes.Text = '*' }
        2  { $txtTypes.Text = 'wav mp3 flac ogg aiff aif m4a wma opus mid midi' }
        3  { $txtTypes.Text = 'mp4 mkv avi mov wmv webm flv m4v' }
        4  { $txtTypes.Text = 'jpg jpeg png gif bmp tif tiff webp svg psd ico' }
        5  { $txtTypes.Text = 'pdf doc docx xls xlsx ppt pptx txt rtf md odt csv' }
        6  { $txtTypes.Text = 'zip rar 7z tar gz bz2 xz iso cab' }
        7  { $txtTypes.Text = 'c cpp h hpp cs py js ts ps1 java rs asm bas lua json xml html css' }
        8  { $txtTypes.Text = 'flp fst wav mid syx' }
        9  { $txtTypes.Text = 'vst3 vst clap' }
        10 { $txtTypes.Text = 'prg d64 d71 d81 t64 tap crt sid p00 seq' }
    }
})

$txtPath.Add_TextChanged({
    $p = $txtPath.Text.Trim().Trim('"')
    if ($p -and (Test-Path -LiteralPath $p -PathType Container)) { $script:Cwd = (Resolve-Path -LiteralPath $p).ProviderPath }
})

# drag & drop a folder (or a file -> its folder)
foreach ($c in @($form, $lv, $inputPanel, $txtPath)) {
    $c.AllowDrop = $true
    $c.Add_DragEnter({
        param($s, $e)
        if ($e.Data.GetDataPresent([System.Windows.Forms.DataFormats]::FileDrop)) {
            $e.Effect = [System.Windows.Forms.DragDropEffects]::Copy
        }
    })
    $c.Add_DragDrop({
        param($s, $e)
        $p = @($e.Data.GetData([System.Windows.Forms.DataFormats]::FileDrop))[0]
        if ((Test-Path -LiteralPath $p -PathType Leaf) -and ([System.IO.Path]::GetExtension($p) -eq '.bas')) {
            if ($split.Panel2Collapsed) { $split.Panel2Collapsed = $false }
            Submit-Term ('RUN "' + $p + '"')
            return
        }
        if (Test-Path -LiteralPath $p -PathType Leaf) { $p = Split-Path -Parent $p }
        $txtPath.Text = $p
    })
}

function Switch-Terminal {
    $split.Panel2Collapsed = -not $split.Panel2Collapsed
    if (-not $split.Panel2Collapsed) { $termIn.Focus() }
}

$form.Add_KeyDown({
    param($s, $e)
    if ($e.KeyCode -eq 'F5') { $e.SuppressKeyPress = $true; Start-GuiSearch $false }
    elseif ($e.KeyCode -eq 'F2') { $e.SuppressKeyPress = $true; Switch-Terminal }
    elseif ($e.KeyCode -eq 'F1') { $e.SuppressKeyPress = $true; Open-Manual }
    elseif ($e.KeyCode -eq 'Escape' -and $script:ActiveShell) { $script:ActiveShell.Kill() }
    elseif ($e.KeyCode -eq 'Escape' -and $script:Busy -and $script:ActiveSlicer) { $script:ActiveSlicer.Cancel = $true }
})

# =====================================================================
#  C64 TERMINAL  --  Commodore DOS + BASIC V2 tribute
# =====================================================================
$basic = New-Object C64Basic

function Send-TermBuf {
    if ($script:TermBuf.Length -eq 0) { return }
    $termOut.SelectionStart = $termOut.TextLength
    $termOut.SelectionLength = 0
    $termOut.SelectionColor = $script:TermFg
    $termOut.AppendText($script:TermBuf.ToString())
    [void]$script:TermBuf.Clear()
}

function Write-Term([string]$Text) {
    if ($termOut.TextLength -gt 300000) { $termOut.Clear() }
    foreach ($ch in $Text.ToCharArray()) {
        $code = [int]$ch
        if ($code -eq 10 -or ($code -ge 32 -and $code -lt 128) -or $code -ge 160) {
            [void]$script:TermBuf.Append($ch)
            continue
        }
        if ($code -eq 13) { continue }
        Send-TermBuf
        if ($code -eq 147) { $termOut.Clear() }
        elseif ($script:PetColors.ContainsKey($code)) { $script:TermFg = $c64Pal[$script:PetColors[$code]] }
    }
    Send-TermBuf
    $termOut.SelectionStart = $termOut.TextLength
    $termOut.ScrollToCaret()
}

function Write-Ready { if (-not $script:InBasic) { Write-Term "READY.`n" } }

function Reset-Term {
    $script:SkipReady = $true
    $pump.Stop()
    $basic.ClearProgram()
    $basic.Col = 0
    $script:ListMode = 'prog'
    $script:DirLines = @()
    $termPanel.BackColor = $c64Pal[14]
    $termOut.BackColor = $c64Pal[6]
    $termIn.BackColor = $c64Pal[6]
    $script:TermFg = $c64Pal[14]
    $termOut.Clear()
    Write-Term "`n    **** FILE SLICER 64 BASIC V2 ****`n`n 64K RAM SYSTEM  38911 BASIC BYTES FREE`n`n"
    Write-Term "TYPE HELP FOR COMMANDS   PROGS FOR PROGRAMS`nLOAD`"`$`",8 THEN LIST   RUN ? PICKS A .BAS FILE`n`n"
    Write-Ready
}

$basic.Out = [System.Action[string]]{ param($s) Write-Term $s }
$basic.OnReset = [System.Action]{ Reset-Term }
$basic.OnPoke = [System.Action[int,int]]{
    param($a, $v)
    $col = $c64Pal[$v -band 15]
    switch ($a) {
        53280 { $termPanel.BackColor = $col }
        53281 { $termOut.BackColor = $col; $termIn.BackColor = $col }
        646   { $script:TermFg = $col }
    }
}

# BASIC run-loop pump
$pump = New-Object System.Windows.Forms.Timer
$pump.Interval = 15
$pump.Add_Tick({
    $pump.Stop()
    $basic.Step(8000)
    $st = $basic.State.ToString()
    if ($st -eq 'Running') { $pump.Start(); return }
    if ($st -eq 'Input') { return }
    if ($script:SkipReady) { $script:SkipReady = $false; return }
    if ($basic.Col -ne 0) { Write-Term "`n" }
    $basic.Col = 0
    Write-Ready
})

# ---- disk-style directory listing -----------------------------------
function Get-DirLines([string]$Pattern) {
    $rx = ConvertTo-WildRegex $Pattern
    $name = Split-Path -Leaf $script:Cwd
    if (-not $name) { $name = $script:Cwd.TrimEnd('\') }
    $lines = New-Object System.Collections.ArrayList
    [void]$lines.Add(('0'.PadRight(5) + '"' + $name.ToUpper().PadRight(16) + '" SL 2A'))
    $items = Get-ChildItem -LiteralPath $script:Cwd -Force -ErrorAction SilentlyContinue |
             Sort-Object @{ Expression = { -not $_.PSIsContainer } }, Name
    foreach ($it in $items) {
        if (-not [regex]::IsMatch($it.Name, $rx, 'IgnoreCase')) { continue }
        if ($it.PSIsContainer) { $blocks = 0; $type = 'DIR' }
        else { $blocks = [int64][math]::Ceiling($it.Length / 254.0); $type = 'PRG' }
        [void]$lines.Add(([string]$blocks).PadRight(5) + '"' + $it.Name.ToUpper().PadRight(16) + '"  ' + $type)
    }
    $free = 664
    try {
        $root = [System.IO.Path]::GetPathRoot($script:Cwd)
        $free = [int64]([System.IO.DriveInfo]::new($root).AvailableFreeSpace / 254)
    } catch { }
    [void]$lines.Add("$free BLOCKS FREE.")
    return @($lines)
}

# ---- bundled BASIC programs (written to the Programs folder on first run) ----
$script:Bundled = [ordered]@{}
$script:ManualHtml = @'
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>斬る File Slicer v16 — Manual</title>
<style>
:root{
  --bg:#141420; --panel:#1e1e2c; --ink:#e6e6ff; --dim:#a4a4c4; --line:#34344a;
  --neon:#00e5ee; --pink:#ff3296; --c64bg:#40318d; --c64fg:#7869c4; --code:#252538;
  --warn:#ffb454;
}
@media (prefers-color-scheme: light){
  :root{ --bg:#f6f6fb; --panel:#ffffff; --ink:#1d1d2e; --dim:#55556f; --line:#d4d4e4; --neon:#006c73; --pink:#b8155f; --code:#eceaf6; --warn:#8a5200; }
}
*{box-sizing:border-box}
html{scroll-behavior:smooth;scroll-padding-top:1.2rem}
body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.65 "Segoe UI",system-ui,sans-serif}
a{color:var(--neon)}
.wrap{display:grid;grid-template-columns:17rem minmax(0,1fr);gap:0;max-width:78rem;margin:0 auto}
nav{position:sticky;top:0;align-self:start;height:100vh;overflow:auto;padding:1.6rem 1.2rem;border-right:1px solid var(--line)}
nav .brand{font-size:1.15rem;font-weight:600;line-height:1.3;margin-bottom:1.2rem}
nav .brand small{display:block;color:var(--dim);font-weight:400;font-size:.85rem}
nav ol{list-style:none;margin:0;padding:0}
nav li{margin:.1rem 0}
nav a{display:block;padding:.28rem .5rem;border-radius:4px;color:var(--ink);text-decoration:none;font-size:.93rem}
nav a:hover,nav a:focus-visible{background:var(--panel);outline:none;box-shadow:inset 3px 0 0 var(--neon)}
nav .grp{margin:.9rem 0 .2rem;color:var(--dim);font-size:.82rem;padding-left:.5rem}
main{padding:2.4rem clamp(1rem,4vw,3.2rem) 5rem;max-width:52rem}
h1{font-size:2.3rem;line-height:1.15;margin:.1rem 0 .4rem}
h1 .kanji{color:var(--pink)}
h2{font-size:1.55rem;margin:3.2rem 0 .6rem;padding-top:1.4rem;border-top:1px solid var(--line)}
h3{font-size:1.15rem;margin:2rem 0 .4rem}
p,li{max-width:70ch}
.lead{font-size:1.15rem;color:var(--dim);max-width:60ch}
code,pre,kbd{font-family:Consolas,"Cascadia Mono",monospace}
code{background:var(--code);padding:.08em .38em;border-radius:3px;font-size:.92em}
kbd{background:var(--panel);border:1px solid var(--line);border-bottom-width:2px;padding:.05em .4em;border-radius:4px;font-size:.88em}
pre{background:var(--code);padding:.9rem 1.1rem;border-radius:6px;overflow-x:auto;line-height:1.45;font-size:.92rem;margin:1rem 0}
pre.c64{background:var(--c64bg);color:#b3a8f0;border:14px solid var(--c64fg);border-radius:4px;padding:.8rem 1rem;font-weight:700;font-size:.95rem}
pre.c64 .w{color:#fff}
pre.c64 .in{color:#fff}
table{border-collapse:collapse;width:100%;margin:1rem 0;font-size:.95rem}
th,td{text-align:left;padding:.5rem .7rem;border-bottom:1px solid var(--line);vertical-align:top}
th{color:var(--dim);font-weight:600;border-bottom:2px solid var(--line)}
td:first-child{white-space:nowrap}
.note{border-left:4px solid var(--neon);background:var(--panel);padding:.7rem 1rem;margin:1.2rem 0;border-radius:0 6px 6px 0}
.warn{border-left-color:var(--warn)}
.note b:first-child{display:block;margin-bottom:.15rem}
.steps{counter-reset:s;list-style:none;padding:0}
.steps>li{counter-increment:s;position:relative;padding-left:2.6rem;margin:1rem 0}
.steps>li::before{content:counter(s);position:absolute;left:0;top:.1rem;width:1.8rem;height:1.8rem;border-radius:50%;background:var(--pink);color:#fff;font-weight:700;text-align:center;line-height:1.8rem;font-size:.9rem}
.cols{display:grid;grid-template-columns:repeat(auto-fit,minmax(15rem,1fr));gap:1rem}
.cols>div{background:var(--panel);padding:.2rem 1rem .6rem;border-radius:6px}
footer{margin-top:4rem;color:var(--dim);font-size:.9rem}
@media (max-width:900px){.wrap{display:block}nav{position:static;height:auto;border-right:0;border-bottom:1px solid var(--line)}}
@media print{
  :root{--bg:#fff;--panel:#f3f3f8;--ink:#111;--dim:#444;--line:#bbb;--neon:#006c73;--pink:#b8155f;--code:#eee}
  nav{display:none}.wrap{display:block}main{max-width:none;padding:0}
  h2{break-after:avoid}pre,table,.note{break-inside:avoid}
  pre.c64{border-width:6px}
}
</style>
</head>
<body>
<div class="wrap">
<nav aria-label="Contents">
  <div class="brand"><span style="color:var(--pink)">斬る</span> File Slicer<small>v16 manual</small></div>
  <ol>
    <li><a href="#start">Quick start</a></li>
    <li><a href="#window">The main window</a></li>
    <li><a href="#search">Searching</a></li>
    <li><a href="#results">Working with results</a></li>
    <li><a href="#dupes">Finding duplicates</a></li>
    <li class="grp">C64 terminal</li>
    <li><a href="#terminal">Terminal basics</a></li>
    <li><a href="#dos">Disk and folder commands</a></li>
    <li><a href="#tsearch">Searching from the terminal</a></li>
    <li><a href="#tresults">Commands for results</a></li>
    <li class="grp">BASIC programs</li>
    <li><a href="#programs">Running programs</a></li>
    <li><a href="#bundled">The bundled programs</a></li>
    <li><a href="#lesson">Write your first program</a></li>
    <li><a href="#basic">BASIC reference</a></li>
    <li><a href="#bridge">BASIC and the slicer</a></li>
    <li class="grp">More</li>
    <li><a href="#shell">Shell pass-through</a></li>
    <li><a href="#files">Files, settings, safety</a></li>
    <li><a href="#trouble">Troubleshooting</a></li>
    <li><a href="#cheat">Cheat sheet</a></li>
  </ol>
</nav>
<main>

<h1><span class="kanji">斬る</span> File Slicer</h1>
<p class="lead">Find big, old, duplicate and misplaced files on Windows, then keep going in a Commodore-64 style terminal that can run BASIC programs, search your drives, and hand commands to cmd or PowerShell.</p>

<h2 id="start">Quick start</h2>
<ol class="steps">
  <li><b>Unzip the folder</b> to somewhere you own, such as <code>C:\Tools\FileSlicer</code>. If Windows blocked the download, right-click the zip, choose Properties, tick <b>Unblock</b>, and only then extract it.</li>
  <li><b>Double-click <code>Run_FileSlicer.bat</code></b>. It starts the script with the right switches, so you don't have to change any PowerShell policy.</li>
  <li><b>Pick a folder</b> with 参照 (Browse), or drag a folder onto the window.</li>
  <li><b>Press <kbd>F5</kbd></b> (切断 Slice). The biggest files appear at the top. Right-click any row for actions.</li>
  <li><b>Press <kbd>F2</kbd></b> to open the terminal at the bottom, and type <code>PROGS</code>.</li>
</ol>
<div class="note"><b>Nothing is deleted without asking.</b>Every delete goes to the Recycle Bin after a confirmation, and BASIC programs cannot delete or run shell commands at all.</div>

<h2 id="window">The main window</h2>
<p>Every label is Japanese first with the English in brackets. Hover over anything for a tooltip.</p>
<table>
<tr><th>Control</th><th>What it does</th></tr>
<tr><td>対象フォルダ (Target Folder)</td><td>The folder to search. The terminal uses the same folder, and changing one changes the other.</td></tr>
<tr><td>参照 (Browse)</td><td>Choose the folder in a dialog.</td></tr>
<tr><td>種類 (File Types)</td><td>Extensions such as <code>wav mp3 flac</code>, or <code>*</code> for every file. Dots and stars are optional, so <code>*.WAV</code>, <code>.wav</code> and <code>wav</code> all mean the same thing.</td></tr>
<tr><td>プリセット (Preset)</td><td>Fills the file-types box with a ready-made list: Audio, Video, Images, Documents, Archives, Code, DAW / FL Studio, Plugins, Commodore 64.</td></tr>
<tr><td>名前 (Name)</td><td>Filter on the file name. Plain text means &ldquo;contains&rdquo;. <code>*</code> and <code>?</code> work as wildcards. Tick 正規表現 (Regex) to use a regular expression instead.</td></tr>
<tr><td>内容 (Contains Text)</td><td>Only files whose contents include this text. Not case sensitive. Reads ASCII and UTF-8 text in files up to 64 MB, so it is slower than the other filters.</td></tr>
<tr><td>最小 / 最大 (Min / Max MB)</td><td>Size limits in megabytes. Decimals are fine: <code>0.5</code>.</td></tr>
<tr><td>日付 (Date)</td><td>Tick it, then choose 以降 (Newer than): modified on or after the date, or 以前 (Older than): modified before it.</td></tr>
<tr><td>サブフォルダ (Subfolders)</td><td>Search inside folders below the target. On by default.</td></tr>
<tr><td>隠しファイル (Hidden)</td><td>Include hidden files. On by default.</td></tr>
<tr><td>切断 (Slice) <kbd>F5</kbd></td><td>Run the search.</td></tr>
<tr><td>中止 (Stop) <kbd>Esc</kbd></td><td>Stop a running search. What was found so far is kept.</td></tr>
<tr><td>重複 (Find Dupes)</td><td>Search with the current filters, but keep only files that have identical copies.</td></tr>
<tr><td>統計 (Stats)</td><td>Prints a per-extension summary of the current results in the terminal.</td></tr>
<tr><td>出力 (Export CSV)</td><td>Saves every result to a CSV file that opens in Excel.</td></tr>
<tr><td>プログラム (Run .bas)</td><td>Same as typing <code>RUN ?</code>. Pick a BASIC program and run it.</td></tr>
<tr><td>端末 (C64 Terminal) <kbd>F2</kbd></td><td>Show or hide the terminal.</td></tr>
</table>
<p>Other keys: <kbd>F1</kbd> opens this manual. The status bar at the bottom shows progress while scanning: files scanned, files matched, and the folder being read.</p>

<h2 id="search">Searching</h2>
<p>All filters combine: a file must pass every one you have filled in. Leave a box empty to ignore it.</p>

<h3>Recipes</h3>
<div class="cols">
<div><h4>Space hogs</h4><p>Types <code>*</code>, Min MB <code>500</code>, press F5. Sorted by size, largest first.</p></div>
<div><h4>Audio you forgot about</h4><p>Preset Audio, tick Date, 以前 (Older than), pick a date two years ago.</p></div>
<div><h4>Which project mentions this?</h4><p>Types <code>txt md json</code>, Contains Text <code>reverb</code>.</p></div>
<div><h4>Numbered exports</h4><p>Tick Regex, Name <code>^Mix_\d{3}\.wav$</code>.</p></div>
<div><h4>Only this folder</h4><p>Untick Subfolders.</p></div>
<div><h4>Big video that is not an MP4</h4><p>Preset Video, Min MB <code>200</code>, then click the 種類 (Type) column to group by format.</p></div>
</div>

<h3>Good to know</h3>
<ul>
<li>Folders you cannot read, and folder shortcuts (junctions and symlinks), are skipped, so a scan never loops.</li>
<li>The window shows the first 25,000 rows. Export, the terminal and BASIC programs still see every result.</li>
<li>Your filters are remembered between sessions (see <a href="#files">Files, settings, safety</a>). If a search finds nothing, look for a leftover filter from last time.</li>
</ul>

<h2 id="results">Working with results</h2>
<p>Click a column header to sort, and click again to reverse. Rows are coloured by size: cyan is normal, pink is 500 MB or more, red is 1 GB or more.</p>
<table>
<tr><th>Action</th><th>How</th></tr>
<tr><td>Open the file</td><td>Double-click, or <kbd>Enter</kbd></td></tr>
<tr><td>Show in Explorer</td><td>Right-click, フォルダを表示 (Show in Folder)</td></tr>
<tr><td>Copy full paths</td><td>Select rows, <kbd>Ctrl</kbd>+<kbd>C</kbd>, or right-click, Copy Path</td></tr>
<tr><td>Select everything</td><td><kbd>Ctrl</kbd>+<kbd>A</kbd></td></tr>
<tr><td>Copy or move</td><td>Right-click, コピー先 (Copy To) or 移動先 (Move To), then choose a folder. Works on many files at once.</td></tr>
<tr><td>Hash a file</td><td>Right-click, SHA-256. The hash goes to the clipboard.</td></tr>
<tr><td>Recycle</td><td><kbd>Delete</kbd> or right-click, ごみ箱へ (Move to Recycle Bin). You are asked first.</td></tr>
</table>

<h2 id="dupes">Finding duplicates</h2>
<p>Press 重複 (Find Dupes). The scanner groups files by size, compares a hash of the first 64 KB, and only then hashes whole files, so it stays quick on large libraries. Matching files share a tag in the 備考 (Note) column, and the list is grouped by that tag. The status bar shows how much space the extra copies waste.</p>
<p>To clean up, open the terminal and type <code>DELDUP</code>. It lists how many extra copies it found, asks for confirmation, and sends them to the Recycle Bin. <b>The oldest copy in each group is kept.</b></p>

<h2 id="terminal">Terminal basics</h2>
<p>Press <kbd>F2</kbd>. The terminal is a small tribute to a Commodore 64: blue screen, light-blue border, BASIC V2 and disk-style commands. Type a command and press <kbd>Enter</kbd>.</p>
<pre class="c64">
    **** FILE SLICER 64 BASIC V2 ****

 64K RAM SYSTEM  38911 BASIC BYTES FREE

TYPE HELP FOR COMMANDS   PROGS FOR PROGRAMS

READY.
<span class="in">FIND *.FLP</span>
</pre>
<ul>
<li><kbd>↑</kbd> and <kbd>↓</kbd> walk through earlier commands.</li>
<li><kbd>Esc</kbd> stops a running search, program or shell command. In a program it is the RUN/STOP key.</li>
<li>Commands are not case sensitive. Text you type in quotes, and the case of regular expressions, is kept as typed.</li>
<li><code>HELP</code> lists commands, <code>HELP FIND</code> explains one, and <code>HELP BASIC</code> lists the slicer extensions for programs.</li>
<li><code>CLS</code> clears the screen, <code>RESET</code> restores the start-up screen, and <code>EXIT</code> hides the terminal.</li>
<li>Searches from the terminal also fill the main list, and the numbers in the terminal are the row numbers of that list.</li>
</ul>

<h2 id="dos">Disk and folder commands</h2>
<p>The current folder is the Target Folder box. The terminal shows folders the way a 1541 disk drive showed a directory: a size in 254-byte &ldquo;blocks&rdquo;, the name in quotes, then <code>PRG</code> or <code>DIR</code>.</p>
<pre class="c64">
<span class="in">LOAD"$",8</span>

SEARCHING FOR $
LOADING
READY.
<span class="in">LIST</span>
0    "MUSIC           " SL 2A
0    "DRUMS           "  DIR
5231 "MIX_001.WAV     "  PRG
</pre>
<table>
<tr><th>Command</th><th>Meaning</th></tr>
<tr><td><code>LOAD"$",8</code> then <code>LIST</code></td><td>Load the directory as a listing, then show it. <code>LOAD"*.WAV",8</code> filters it. The <code>,8</code> is optional.</td></tr>
<tr><td><code>DIR</code> or <code>CATALOG</code> <code>[pattern]</code></td><td>Show the current folder directly, without loading it first.</td></tr>
<tr><td><code>CD path</code>, <code>CD ..</code>, <code>PWD</code></td><td>Change or show the current folder. The Target Folder box follows.</td></tr>
<tr><td><code>DISK</code></td><td>Total, used and free space of the current drive.</td></tr>
<tr><td><code>SCRATCH file</code></td><td>Send a file to the Recycle Bin (asks first).</td></tr>
<tr><td><code>RENAME old TO new</code></td><td>Rename a file. Refuses if the new name already exists.</td></tr>
<tr><td><code>COPY a TO b</code></td><td>Copy a file. Refuses to overwrite.</td></tr>
</table>

<h2 id="tsearch">Searching from the terminal</h2>
<p>Every search starts in the current folder and looks in all subfolders. Quote anything containing spaces.</p>
<table>
<tr><th>Command</th><th>Example</th><th>Finds</th></tr>
<tr><td><code>FIND</code></td><td><code>FIND *mix*</code></td><td>Names matching a pattern (<code>*</code> and <code>?</code>)</td></tr>
<tr><td><code>EXT</code></td><td><code>EXT wav mp3</code></td><td>File types</td></tr>
<tr><td><code>GREP</code></td><td><code>GREP "delay time"</code></td><td>Files containing text</td></tr>
<tr><td><code>REGEX</code></td><td><code>REGEX ^\d{4}-\d\d-\d\d.*\.log$</code></td><td>Names matching a regular expression</td></tr>
<tr><td><code>BIG</code></td><td><code>BIG 20</code></td><td>The 20 largest files</td></tr>
<tr><td><code>NEWER</code></td><td><code>NEWER 7</code></td><td>Changed in the last 7 days</td></tr>
<tr><td><code>OLDER</code></td><td><code>OLDER 365</code></td><td>Not changed for a year</td></tr>
<tr><td><code>DUPES</code></td><td><code>DUPES</code></td><td>Duplicate files</td></tr>
<tr><td><code>SLICE</code></td><td><code>SLICE ext=wav min=50 older=180</code></td><td>Any combination (below)</td></tr>
</table>
<h3>SLICE options</h3>
<p>Write them as <code>key=value</code>, in any order. All of them must match.</p>
<table>
<tr><th>Key</th><th>Meaning</th></tr>
<tr><td><code>name=</code></td><td>Name pattern, for example <code>name=*take*</code></td></tr>
<tr><td><code>ext=</code> or <code>type=</code></td><td>File types, for example <code>ext=wav,flac</code> or <code>ext="wav flac"</code></td></tr>
<tr><td><code>min=</code>, <code>max=</code></td><td>Size in megabytes</td></tr>
<tr><td><code>text=</code> or <code>grep=</code></td><td>Text inside files. Use quotes for spaces: <code>text="two words"</code></td></tr>
<tr><td><code>newer=</code>, <code>older=</code></td><td>Days since last modified</td></tr>
<tr><td><code>sub=0</code></td><td>Do not search subfolders</td></tr>
<tr><td><code>hidden=0</code></td><td>Skip hidden files</td></tr>
</table>
<pre class="c64">
<span class="in">SLICE EXT=WAV MIN=100 OLDER=365</span>
SEARCHING C:\MUSIC
  1  812.44 MB C:\MUSIC\OLD\BOUNCE_FINAL.WAV
  2  640.10 MB C:\MUSIC\2023\STEMS_ALL.WAV
2 FILES FOUND. (18342 SCANNED, 3.1S)
READY.
</pre>

<h2 id="tresults">Commands for results</h2>
<table>
<tr><th>Command</th><th>Meaning</th></tr>
<tr><td><code>SORT SIZE|DATE|TYPE|NAME|DIR</code> <code>[ASC|DESC]</code></td><td>Re-sort the list. Size and date default to largest and newest first.</td></tr>
<tr><td><code>HEAD 20</code></td><td>Print the first 20 rows of the list.</td></tr>
<tr><td><code>STATS</code></td><td>Count and total size per extension, with bars.</td></tr>
<tr><td><code>SIZE</code></td><td>Total size of the current folder. Accepts the same options as SLICE.</td></tr>
<tr><td><code>OPEN 3</code>, <code>EXPLORE 3</code></td><td>Open row 3, or show it in Explorer.</td></tr>
<tr><td><code>EXPORT [file.csv]</code></td><td>Save the list as CSV. A bare name goes in the current folder.</td></tr>
<tr><td><code>DELDUP</code></td><td>After DUPES: recycle the extra copies (asks first).</td></tr>
<tr><td><code>ALIAS DF = DUPES</code></td><td>Create a shortcut. <code>ALIAS</code> alone lists them, and <code>ALIAS DF =</code> removes one. Aliases are saved.</td></tr>
</table>

<h2 id="programs">Running programs</h2>
<p>Programs are plain text files ending in <code>.bas</code>, with a line number on every line. There are four ways to run one:</p>
<table>
<tr><th>You do</th><th>What happens</th></tr>
<tr><td>Type <code>RUN ?</code> or press the プログラム (Run .bas) button</td><td>A file dialog opens in the Programs folder. Pick a file and it runs.</td></tr>
<tr><td>Type <code>RUN "BIGFILES"</code></td><td>Looks in the current folder, then the Programs folder. The <code>.bas</code> is optional.</td></tr>
<tr><td>Drag a <code>.bas</code> file onto the window</td><td>It runs in the terminal.</td></tr>
<tr><td><code>LOAD"NAME.BAS",8</code> then <code>LIST</code>, <code>RUN</code></td><td>Load without running, so you can read or change it first.</td></tr>
</table>
<p><code>PROGS</code> lists what is in the Programs folder with a description of each program, taken from its first <code>REM</code> line. <code>RUN 100</code> starts the program in memory at line 100, and <code>NEW</code> clears it.</p>
<div class="note"><b>Your own programs</b>Put your <code>.bas</code> files in the Programs folder and they show up in <code>PROGS</code>. The script recreates bundled programs that are missing but never overwrites one you edited.</div>

<h2 id="bundled">The bundled programs</h2>
<p>Each one asks for a folder first (press Enter to use the current one), then does its job.</p>
<table>
<tr><th>Program</th><th>What it does</th></tr>
<tr><td><code>BIGFILES</code></td><td>Asks for a minimum size in MB, lists the 25 largest files with sizes, and can open one.</td></tr>
<tr><td><code>DUPEHUNT</code></td><td>Finds duplicate files, prints each group and the total wasted space. Follow up with <code>DELDUP</code>.</td></tr>
<tr><td><code>OLDSTUFF</code></td><td>Large files nobody has touched in N days. Shows how much could be archived and can save a CSV.</td></tr>
<tr><td><code>AUDIOSCAN</code></td><td>Summarises audio by format: file count, total size and a bar chart.</td></tr>
<tr><td><code>RECENTFLP</code></td><td>Your newest FL Studio projects, newest first, with the option to show one in Explorer.</td></tr>
<tr><td><code>FINDTEXT</code></td><td>Asks for file types and a piece of text, lists the files that contain it, and can open one.</td></tr>
<tr><td><code>HELLO</code></td><td>Colour tour and pointers.</td></tr>
<tr><td><code>GUESS</code></td><td>Number guessing game.</td></tr>
<tr><td><code>COLORS</code></td><td>Cycles the border and background colours with <code>POKE</code>. Type <code>RESET</code> afterwards if you stopped it half-way.</td></tr>
</table>

<h2 id="lesson">Write your first program</h2>
<p>We will write a program that lists every WAV file over 50 MB. You type each line into the terminal, then run it.</p>
<ol class="steps">
<li><b>Start clean.</b> Type <code>NEW</code>.</li>
<li><b>Add the lines.</b> Type these, pressing Enter after each one:
<pre>10 REM MYWAVS - BIG WAV FILES
20 CMD "SLICE EXT=WAV MIN=50"
30 N=RC(0)
40 IF N=0 THEN PRINT "NONE FOUND":END
50 FOR I=1 TO N
60 PRINT FS$(RS(I));TAB(12);RN$(I)
70 NEXT I
80 PRINT N;"FILES"</pre>
Line 20 runs a search in the current folder. <code>RC(0)</code> is how many files it found. <code>RS(I)</code> is the size in bytes of result number I, <code>FS$()</code> turns bytes into text like <code>1.20 GB</code>, and <code>RN$(I)</code> is the file name.</li>
<li><b>Check it.</b> Type <code>LIST</code> to see the program. Retype a line number to replace that line, or type just the number to delete it.</li>
<li><b>Run it.</b> Type <code>RUN</code>. Press <kbd>Esc</kbd> to stop.</li>
<li><b>Save it.</b> Type <code>SAVE"MYWAVS.BAS",8</code>. It is written to the current folder. To have it appear in <code>PROGS</code>, copy it into the Programs folder: <code>COPY MYWAVS.BAS TO C:\Tools\FileSlicer\Programs\MYWAVS.BAS</code>. <code>PROGS</code> prints the exact path of that folder on its first line.</li>
<li><b>Make it ask.</b> Replace line 20 with these two lines, and change <code>MIN=50</code> into a question:
<pre>15 INPUT "MINIMUM MB";M
20 CMD "SLICE EXT=WAV MIN="+MID$(STR$(M),2)</pre>
<code>STR$(M)</code> puts a space in front of positive numbers, and <code>MID$(...,2)</code> removes it.</li>
</ol>

<h2 id="basic">BASIC reference</h2>
<p>The language is modelled on Commodore BASIC V2. Lines look like <code>10 PRINT "HI"</code>. Several statements can share a line, separated by <code>:</code>. A statement typed without a line number runs at once.</p>
<h3>Statements</h3>
<table>
<tr><th>Statement</th><th>Notes</th></tr>
<tr><td><code>PRINT</code> (or <code>?</code>)</td><td><code>;</code> joins items, <code>,</code> jumps to the next 10-column tab stop, <code>TAB(n)</code> moves to column n, <code>SPC(n)</code> prints n spaces. A trailing <code>;</code> suppresses the new line. Numbers print with a leading space (or a minus sign) and a trailing space, as on the C64.</td></tr>
<tr><td><code>INPUT ["prompt";] var[,var]</code></td><td>Reads a line. With a single variable the whole line is used, commas and all, so paths work.</td></tr>
<tr><td><code>LET</code> or plain assignment</td><td><code>A=5</code>, <code>N$="HI"</code>, <code>X(3)=7</code></td></tr>
<tr><td><code>IF cond THEN line</code> / <code>THEN statement</code></td><td>If false, the rest of the line is skipped. There is no <code>ELSE</code>. <code>IF ... GOTO n</code> also works.</td></tr>
<tr><td><code>GOTO n</code>, <code>GOSUB n</code>, <code>RETURN</code></td><td>Jumps and subroutines.</td></tr>
<tr><td><code>FOR v=a TO b [STEP c]</code> / <code>NEXT [v]</code></td><td>The body always runs at least once, as on the C64.</td></tr>
<tr><td><code>DIM A(10)</code>, <code>DIM B$(5,5)</code></td><td>Arrays. Indexes start at 0. An array used without DIM gets room for 0 to 10.</td></tr>
<tr><td><code>DATA</code>, <code>READ</code>, <code>RESTORE</code></td><td>Built-in data lists.</td></tr>
<tr><td><code>POKE addr,value</code></td><td>Writes to a pretend 64 KB memory. Some addresses change the terminal, see below.</td></tr>
<tr><td><code>SYS 64738</code></td><td>Reset, like switching the machine on.</td></tr>
<tr><td><code>CLR</code>, <code>REM</code>, <code>END</code>, <code>STOP</code></td><td>Clear variables, comment, finish, and break with a message.</td></tr>
<tr><td><code>CMD "text"</code></td><td>Run a slicer command from a program. See <a href="#bridge">BASIC and the slicer</a>.</td></tr>
</table>
<h3>Operators, functions and variables</h3>
<ul>
<li>Arithmetic: <code>+ - * / ^</code>. Comparison: <code>= &lt;&gt; &lt; &gt; &lt;= &gt;=</code>. Logic: <code>AND OR NOT</code>. True is <code>-1</code> and false is <code>0</code>.</li>
<li>Numbers: <code>ABS INT SQR SIN COS TAN ATN LOG EXP SGN RND(1)</code>.</li>
<li>Text: <code>LEN VAL ASC CHR$ STR$ LEFT$ RIGHT$ MID$</code>. Join text with <code>+</code>. Strings compare exactly, so <code>"y"</code> and <code>"Y"</code> differ.</li>
<li>System: <code>PEEK(addr)</code>, <code>FRE(0)</code>, <code>POS(0)</code>, <code>TI</code> (60 ticks per second), <code>TI$</code> (time as HHMMSS), <code>PI</code>.</li>
<li>Variable names ending in <code>$</code> hold text. Do not start a variable name with a statement word: <code>IFACE</code>, <code>FORMAT</code>, <code>LETTER</code> and <code>REMAIN</code> would be read as <code>IF</code>, <code>FOR</code>, <code>LET</code> and <code>REM</code>. This is the same trap as on the real C64.</li>
<li>Not available: <code>MOD</code>, <code>ELSE</code>, <code>ON ... GOTO</code>, <code>GET</code>, files. Use <code>X-INT(X/4)*4</code> instead of <code>X MOD 4</code>.</li>
</ul>
<h3>Colours and screen codes</h3>
<p>Print these with <code>PRINT CHR$(n)</code>. They apply to the text printed after them.</p>
<table>
<tr><th>Code</th><th>Effect</th><th>Code</th><th>Effect</th></tr>
<tr><td>147</td><td>Clear screen</td><td>5</td><td>White</td></tr>
<tr><td>28</td><td>Red</td><td>30</td><td>Green</td></tr>
<tr><td>31</td><td>Blue</td><td>158</td><td>Yellow</td></tr>
<tr><td>159</td><td>Cyan</td><td>156</td><td>Purple</td></tr>
<tr><td>144</td><td>Black</td><td>129</td><td>Orange</td></tr>
<tr><td>149</td><td>Brown</td><td>150</td><td>Light red</td></tr>
<tr><td>151</td><td>Dark grey</td><td>152</td><td>Grey</td></tr>
<tr><td>153</td><td>Light green</td><td>154</td><td>Light blue</td></tr>
<tr><td>155</td><td>Light grey</td><td>13</td><td>New line</td></tr>
</table>
<h3>POKE addresses that do something</h3>
<table>
<tr><th>Address</th><th>Effect</th></tr>
<tr><td><code>53280</code></td><td>Border colour, 0 to 15</td></tr>
<tr><td><code>53281</code></td><td>Screen colour, 0 to 15</td></tr>
<tr><td><code>646</code></td><td>Text colour, 0 to 15</td></tr>
</table>
<p>Colour numbers are the classic C64 palette: 0 black, 1 white, 2 red, 3 cyan, 4 purple, 5 green, 6 blue, 7 yellow, 8 orange, 9 brown, 10 light red, 11 dark grey, 12 grey, 13 light green, 14 light blue, 15 light grey.</p>

<h2 id="bridge">BASIC and the slicer</h2>
<p>These extras let a program search your files and use the answers. Results are numbered from 1, in the same order as the rows in the main list.</p>
<table>
<tr><th>Item</th><th>Meaning</th></tr>
<tr><td><code>CMD "command"</code></td><td>Run a slicer command. Search commands (<code>FIND EXT GREP NEWER OLDER SLICE DUPES BIG REGEX</code>) run silently so the program can print its own report. Others (<code>STATS SIZE DIR CD SORT HEAD EXPORT OPEN EXPLORE DISK PWD</code>) print normally. Any other command is refused with <code>?ILLEGAL DIRECT ERROR</code>.</td></tr>
<tr><td><code>RC(0)</code></td><td>Number of results</td></tr>
<tr><td><code>RP$(i)</code> <code>RN$(i)</code></td><td>Full path, file name of result i</td></tr>
<tr><td><code>RS(i)</code></td><td>Size of result i in bytes</td></tr>
<tr><td><code>RD$(i)</code></td><td>Modified date, like <code>2026-03-14 09:30</code></td></tr>
<tr><td><code>RX$(i)</code></td><td>Extension without the dot, upper case, like <code>WAV</code></td></tr>
<tr><td><code>RG$(i)</code></td><td>Duplicate group tag (after <code>DUPES</code>)</td></tr>
<tr><td><code>FS$(bytes)</code></td><td>Formats bytes, like <code>1.20 GB</code></td></tr>
<tr><td><code>CWD$</code></td><td>The current folder</td></tr>
</table>
<p>Use <code>CMD "SORT DATE DESC"</code> before reading results if you want them in a particular order. Asking for a result number that does not exist stops the program with <code>?ILLEGAL QUANTITY ERROR</code>.</p>
<div class="note warn"><b>Safety</b>Programs can search, open a file and export a CSV, but they cannot delete anything and cannot use the shell pass-through. Running a <code>.bas</code> file you downloaded is therefore safe in a way running a script is not.</div>

<h2 id="shell">Shell pass-through</h2>
<p>Start a line with a backslash to send it to a real Windows shell instead of the C64 interpreter.</p>
<table>
<tr><th>Type</th><th>Runs in</th></tr>
<tr><td><code>\c dir /s *.wav</code></td><td>Command Prompt (<code>cmd.exe</code>)</td></tr>
<tr><td><code>\p Get-ChildItem | Sort Length -Desc | Select -First 5</code></td><td>Windows PowerShell 5.1</td></tr>
<tr><td><code>\7 $PSVersionTable.PSVersion</code></td><td>PowerShell 7 (<code>pwsh</code>), if it is installed</td></tr>
<tr><td><code>\c</code>, <code>\p</code> or <code>\7</code> on its own</td><td>Stay in that shell. Every line goes to it until you leave. The prompt shows the folder.</td></tr>
<tr><td><code>\s</code></td><td>Return to the C64 interpreter. <code>exit</code> does the same while in a shell.</td></tr>
<tr><td><code>\?</code></td><td>Short help</td></tr>
</table>
<pre class="c64">
<span class="in">\C ECHO HELLO FROM CMD</span>
HELLO FROM CMD
READY.
<span class="in">\P</span>
POWERSHELL MODE - TYPE \S TO RETURN TO C64
<span class="in">PS C:\MUSIC&gt; (GET-ITEM .\MIX.WAV).LENGTH</span>
52428800
<span class="in">PS C:\MUSIC&gt; CD ..</span>
<span class="in">PS C:\&gt; \S</span>
BACK TO C64 MODE
READY.
</pre>
<ul>
<li>Commands start in the current folder, and a <code>cd</code> inside the shell moves the slicer's folder too, so <code>\c cd D:\Samples</code> followed by <code>BIG 10</code> works as you would hope.</li>
<li>Output streams in as it arrives. Press <kbd>Esc</kbd> to stop a command that keeps running, such as <code>ping -t</code>.</li>
<li>The shell has no keyboard input. Anything that waits for a keypress or a prompt, like <code>pause</code> or <code>Read-Host</code>, ends immediately instead of hanging.</li>
<li>PowerShell runs with <code>-NoProfile</code>, so your profile is not loaded. Commands run with the same permissions as File Slicer: start it as administrator and they are administrator commands.</li>
<li>Typing <code>\</code> commands is the only way to reach the shell. BASIC programs cannot.</li>
</ul>

<h2 id="files">Files, settings, safety</h2>
<table>
<tr><th>What</th><th>Where</th></tr>
<tr><td>Programs</td><td><code>Programs\</code> next to the script. If that folder is not writable, <code>%APPDATA%\FileSlicer64\Programs</code>. <code>PROGS</code> shows which one is in use.</td></tr>
<tr><td>Manual</td><td><code>MANUAL.html</code> in the same folder as <code>Programs\</code>. Press <kbd>F1</kbd> or type <code>MANUAL</code>.</td></tr>
<tr><td>Settings</td><td><code>%APPDATA%\FileSlicer64\settings.json</code>: target folder, filters, checkboxes and aliases. Delete the file to start fresh.</td></tr>
<tr><td>CSV exports</td><td>Wherever you choose, or the current folder for <code>EXPORT name.csv</code>.</td></tr>
</table>
<p>File Slicer only reads files, apart from the actions you choose: copy, move, recycle, rename, save a program, export a CSV. Deletes always go to the Recycle Bin and always ask first. Network drives that have no Recycle Bin may refuse the delete.</p>

<h2 id="trouble">Troubleshooting</h2>
<table>
<tr><th>Symptom</th><th>Fix</th></tr>
<tr><td>&ldquo;Running scripts is disabled on this system&rdquo;</td><td>Start with <code>Run_FileSlicer.bat</code>, or run <code>powershell -ExecutionPolicy Bypass -File .\FileSlicer_v16.ps1</code>.</td></tr>
<tr><td>Windows warns the file came from the internet</td><td>Right-click the zip, Properties, tick Unblock, then extract again. Or run <code>Get-ChildItem -Recurse | Unblock-File</code> in the folder.</td></tr>
<tr><td>Japanese text shows as ???</td><td>The <code>.ps1</code> must be saved as UTF-8 <b>with</b> BOM. If you edit it, use an editor that keeps the BOM (VS Code: &ldquo;UTF-8 with BOM&rdquo;).</td></tr>
<tr><td>Dragging a folder onto the window does nothing</td><td>Windows blocks drag and drop between a normal Explorer and an administrator window. Start File Slicer without administrator rights, or use Browse.</td></tr>
<tr><td>A search finds nothing</td><td>Check File Types is <code>*</code> or the right list, and clear Name, Contains Text and Date. Filters from your last session are restored at start-up.</td></tr>
<tr><td>Content search is slow</td><td>It reads each file. Narrow the file types first, for example <code>txt log md</code>.</td></tr>
<tr><td>Terminal says <code>?SYNTAX ERROR</code></td><td>The line was not a command or valid BASIC. <code>HELP</code> shows the commands. In a program, the line number is shown after <code>IN</code>.</td></tr>
<tr><td><code>?ILLEGAL DIRECT ERROR</code> inside a program</td><td><code>CMD</code> only allows the safe search and display commands listed above.</td></tr>
<tr><td>Colours are stuck after stopping COLORS</td><td>Type <code>RESET</code> (or <code>SYS 64738</code>).</td></tr>
<tr><td><code>\7</code> says PowerShell 7 not installed</td><td>Install it from the Microsoft Store or <code>winget install Microsoft.PowerShell</code>, or use <code>\p</code>.</td></tr>
</table>

<h2 id="cheat">Cheat sheet</h2>
<div class="cols">
<div>
<h4>Keys</h4>
<p><kbd>F5</kbd> slice<br><kbd>F2</kbd> terminal<br><kbd>F1</kbd> manual<br><kbd>Esc</kbd> stop / RUN-STOP<br><kbd>↑</kbd> <kbd>↓</kbd> command history<br><kbd>Ctrl</kbd>+<kbd>C</kbd> copy paths</p>
</div>
<div>
<h4>Search</h4>
<p><code>FIND *mix*</code><br><code>EXT wav mp3</code><br><code>GREP text</code><br><code>REGEX ^a.*\.txt$</code><br><code>BIG 20</code><br><code>NEWER 7</code> / <code>OLDER 365</code><br><code>DUPES</code> then <code>DELDUP</code><br><code>SLICE ext=wav min=50</code></p>
</div>
<div>
<h4>Results</h4>
<p><code>SORT DATE DESC</code><br><code>HEAD 20</code><br><code>STATS</code><br><code>OPEN 3</code> / <code>EXPLORE 3</code><br><code>EXPORT out.csv</code><br><code>ALIAS X = command</code></p>
</div>
<div>
<h4>Programs</h4>
<p><code>PROGS</code><br><code>RUN ?</code><br><code>RUN "NAME"</code><br><code>LIST</code> <code>NEW</code> <code>RUN 100</code><br><code>SAVE"X.BAS",8</code><br><code>LOAD"X.BAS",8</code></p>
</div>
<div>
<h4>BASIC extras</h4>
<p><code>CMD "SLICE MIN=100"</code><br><code>RC(0)</code> count<br><code>RP$(i)</code> <code>RN$(i)</code> <code>RX$(i)</code><br><code>RS(i)</code> <code>RD$(i)</code> <code>RG$(i)</code><br><code>FS$(n)</code> <code>CWD$</code></p>
</div>
<div>
<h4>Shells</h4>
<p><code>\c dir</code> cmd<br><code>\p Get-Date</code> PowerShell<br><code>\7 ...</code> PowerShell 7<br><code>\c</code> stay in cmd<br><code>\s</code> back to C64</p>
</div>
</div>

<footer>斬る File Slicer v16</footer>
</main>
</div>
</body>
</html>
'@
$script:Bundled['AUDIOSCAN.BAS'] = @'
10 REM AUDIOSCAN - AUDIO LIBRARY SUMMARY BY FORMAT
20 PRINT CHR$(147);"AUDIOSCAN - WHAT AUDIO DO I HAVE?"
30 PRINT "FOLDER (BLANK = ";CWD$;")";
40 INPUT F$
50 IF F$<>"" THEN CMD "CD "+F$
60 PRINT "SCANNING FOR AUDIO FILES..."
70 CMD "EXT WAV MP3 FLAC OGG AIFF AIF M4A WMA OPUS MID"
80 N=RC(0)
90 IF N=0 THEN PRINT "NO AUDIO FOUND.":END
100 DIM E$(20),C(20),S(20)
110 U=0
120 FOR I=1 TO N
130 X$=RX$(I)
140 K=0
150 FOR J=1 TO U
160 IF E$(J)=X$ THEN K=J
170 NEXT J
180 IF K=0 THEN U=U+1:K=U:E$(K)=X$
190 C(K)=C(K)+1:S(K)=S(K)+RS(I)
200 NEXT I
210 BM=1:T=0
220 FOR J=1 TO U:T=T+S(J):IF S(J)>BM THEN BM=S(J)
230 NEXT J
240 PRINT
250 PRINT "FORMAT";TAB(9);"FILES";TAB(18);"SIZE";TAB(30);"SHARE"
260 FOR J=1 TO U
270 PRINT E$(J);TAB(9);MID$(STR$(C(J)),2);TAB(18);FS$(S(J));TAB(30);
280 FOR K=1 TO INT(30*S(J)/BM):PRINT "#";:NEXT K
290 PRINT
300 NEXT J
310 PRINT
320 PRINT MID$(STR$(N),2);" FILES, ";FS$(T)
'@
$script:Bundled['BIGFILES.BAS'] = @'
10 REM BIGFILES - LARGEST FILES IN A FOLDER TREE
20 PRINT CHR$(147);"BIGFILES - FIND THE SPACE HOGS"
30 PRINT "FOLDER (BLANK = ";CWD$;")";
40 INPUT F$
50 IF F$<>"" THEN CMD "CD "+F$
60 PRINT "MINIMUM SIZE IN MB (BLANK = 100)";
70 INPUT M$
80 M=100:IF M$<>"" THEN M=VAL(M$)
90 PRINT "SCANNING ";CWD$;" ..."
100 CMD "SLICE MIN="+MID$(STR$(M),2)
110 N=RC(0)
120 IF N=0 THEN PRINT "NOTHING THAT BIG. GOOD JOB!":END
130 T=0
140 FOR I=1 TO N:T=T+RS(I):NEXT I
150 PRINT
160 PRINT N;"FILES, ";FS$(T);" IN TOTAL"
170 PRINT
180 L=N:IF L>25 THEN L=25
190 FOR I=1 TO L
200 PRINT FS$(RS(I));TAB(12);RP$(I)
210 NEXT I
220 IF N>L THEN PRINT "... AND";N-L;"MORE (SEE THE LIST ABOVE)"
230 PRINT
240 PRINT "OPEN WHICH ONE? (0 = NONE)";
250 INPUT K
260 IF K>=1 AND K<=L THEN CMD "OPEN "+MID$(STR$(K),2)
'@
$script:Bundled['COLORS.BAS'] = @'
10 REM COLORS - BORDER AND BACKGROUND SHOW (ESC STOPS)
20 PRINT CHR$(147);"COLOR SHOW - ESC STOPS, RESET RESTORES"
30 FOR C=0 TO 15
40 POKE 53280,C:POKE 53281,15-C:POKE 646,C
50 PRINT "BORDER=";C;" BACKGROUND=";15-C
60 T=TI
70 IF TI<T+12 THEN GOTO 70
80 NEXT C
90 POKE 53280,14:POKE 53281,6:POKE 646,14
100 PRINT "DONE."
'@
$script:Bundled['DUPEHUNT.BAS'] = @'
10 REM DUPEHUNT - FIND DUPLICATE FILES AND WASTED SPACE
20 PRINT CHR$(147);"DUPEHUNT - IDENTICAL FILES"
30 PRINT "FOLDER (BLANK = ";CWD$;")";
40 INPUT F$
50 IF F$<>"" THEN CMD "CD "+F$
60 PRINT "HASHING - THIS CAN TAKE A WHILE. ESC STOPS."
70 CMD "DUPES"
80 N=RC(0)
90 IF N=0 THEN PRINT "NO DUPLICATES FOUND.":END
100 G=0:W=0:P$=""
110 FOR I=1 TO N
120 IF RG$(I)<>P$ THEN G=G+1:P$=RG$(I):GOTO 140
130 W=W+RS(I)
140 NEXT I
150 PRINT
160 PRINT N;"FILES IN";G;"GROUPS OF DUPLICATES"
170 PRINT "WASTED SPACE: ";FS$(W)
180 L=N:IF L>30 THEN L=30
190 P$=""
200 FOR I=1 TO L
210 IF RG$(I)<>P$ THEN PRINT:PRINT "GROUP ";RG$(I);" - ";FS$(RS(I));" EACH":P$=RG$(I)
220 PRINT "  ";RP$(I)
230 NEXT I
240 IF N>L THEN PRINT:PRINT "... SEE THE LIST ABOVE FOR ALL";N
250 PRINT
260 PRINT "TIP: TYPE  DELDUP  TO RECYCLE THE EXTRA COPIES"
270 PRINT "     (THE OLDEST COPY IN EACH GROUP IS KEPT)."
'@
$script:Bundled['FINDTEXT.BAS'] = @'
10 REM FINDTEXT - FIND FILES THAT CONTAIN SOME TEXT
20 PRINT CHR$(147);"FINDTEXT - SEARCH INSIDE FILES"
30 PRINT "FOLDER (BLANK = ";CWD$;")";
40 INPUT F$
50 IF F$<>"" THEN CMD "CD "+F$
60 PRINT "FILE TYPES, E.G. TXT LOG CPP (BLANK = ALL)";
70 INPUT T$
80 PRINT "TEXT TO FIND";
90 INPUT X$
100 IF X$="" THEN PRINT "NOTHING TO SEARCH FOR.":END
110 O$="SLICE TEXT="+CHR$(34)+X$+CHR$(34)
120 IF T$<>"" THEN O$=O$+" EXT="+CHR$(34)+T$+CHR$(34)
130 PRINT "SEARCHING..."
140 CMD O$
150 N=RC(0)
160 IF N=0 THEN PRINT "NO FILES CONTAIN THAT TEXT.":END
170 PRINT
180 PRINT N;"FILES FOUND:"
190 L=N:IF L>30 THEN L=30
200 FOR I=1 TO L:PRINT MID$(STR$(I),2);". ";RP$(I):NEXT I
210 IF N>L THEN PRINT "... SEE THE LIST ABOVE FOR ALL"
220 PRINT
230 PRINT "OPEN WHICH ONE? (0 = NONE)";
240 INPUT K
250 IF K>=1 AND K<=L THEN CMD "OPEN "+MID$(STR$(K),2)
'@
$script:Bundled['GUESS.BAS'] = @'
10 REM GUESS - NUMBER GUESSING GAME
20 PRINT CHR$(147);"GUESS THE NUMBER (1-100)"
30 N=INT(RND(1)*100)+1:C=0
40 PRINT "YOUR GUESS";
50 INPUT G
60 C=C+1
70 IF G<N THEN PRINT "TOO LOW":GOTO 40
80 IF G>N THEN PRINT "TOO HIGH":GOTO 40
90 PRINT "CORRECT IN";C;"TRIES!"
'@
$script:Bundled['HELLO.BAS'] = @'
10 REM HELLO - WELCOME TOUR AND COLOR DEMO
20 PRINT CHR$(147);CHR$(5)
30 PRINT "**** FILE SLICER 64 ****"
40 PRINT
50 PRINT CHR$(28);"RED ";CHR$(30);"GREEN ";CHR$(31);"BLUE ";CHR$(158);"YELLOW ";CHR$(159);"CYAN ";CHR$(156);"PURPLE"
60 PRINT CHR$(5)
70 PRINT "CURRENT FOLDER: ";CWD$
80 PRINT
90 PRINT "TYPE  PROGS  TO SEE THE BUNDLED PROGRAMS."
100 PRINT "TYPE  RUN ?  TO PICK ANY .BAS FILE."
110 PRINT "TYPE  HELP BASIC  FOR THE SLICER EXTENSIONS."
'@
$script:Bundled['OLDSTUFF.BAS'] = @'
10 REM OLDSTUFF - LARGE FILES NOBODY HAS TOUCHED IN AGES
20 PRINT CHR$(147);"OLDSTUFF - CLEANUP CANDIDATES"
30 PRINT "FOLDER (BLANK = ";CWD$;")";
40 INPUT F$
50 IF F$<>"" THEN CMD "CD "+F$
60 PRINT "NOT MODIFIED FOR HOW MANY DAYS (BLANK = 365)";
70 INPUT D$
80 D=365:IF D$<>"" THEN D=VAL(D$)
90 PRINT "AT LEAST HOW MANY MB (BLANK = 50)";
100 INPUT M$
110 M=50:IF M$<>"" THEN M=VAL(M$)
120 PRINT "SCANNING..."
130 CMD "SLICE OLDER="+MID$(STR$(D),2)+" MIN="+MID$(STR$(M),2)
140 N=RC(0)
150 IF N=0 THEN PRINT "NOTHING MATCHES. TIDY DISK!":END
160 T=0
170 FOR I=1 TO N:T=T+RS(I):NEXT I
180 PRINT
190 PRINT N;"FILES, ";FS$(T);" COULD BE ARCHIVED OR DELETED"
200 PRINT
210 L=N:IF L>20 THEN L=20
220 FOR I=1 TO L
230 PRINT RD$(I);"  ";FS$(RS(I));TAB(32);RP$(I)
240 NEXT I
250 PRINT
260 PRINT "SAVE THE FULL LIST AS OLDSTUFF.CSV (Y/N)";
270 INPUT Y$
280 IF LEFT$(Y$,1)="Y" OR LEFT$(Y$,1)="y" THEN CMD "EXPORT OLDSTUFF.CSV"
'@
$script:Bundled['RECENTFLP.BAS'] = @'
10 REM RECENTFLP - NEWEST FL STUDIO PROJECTS
20 PRINT CHR$(147);"RECENTFLP - NEWEST .FLP PROJECTS"
30 PRINT "FOLDER (BLANK = ";CWD$;")";
40 INPUT F$
50 IF F$<>"" THEN CMD "CD "+F$
60 PRINT "SCANNING..."
70 CMD "EXT FLP"
80 N=RC(0)
90 IF N=0 THEN PRINT "NO .FLP FILES FOUND.":END
100 CMD "SORT DATE DESC"
110 PRINT
120 PRINT N;"PROJECTS. NEWEST FIRST:"
130 PRINT
140 L=N:IF L>25 THEN L=25
150 FOR I=1 TO L
160 PRINT RD$(I);"  ";FS$(RS(I));TAB(30);RN$(I)
170 NEXT I
180 PRINT
190 PRINT "SHOW WHICH IN EXPLORER? (0 = NONE)";
200 INPUT K
210 IF K>=1 AND K<=L THEN CMD "EXPLORE "+MID$(STR$(K),2)
'@

# ---- option parsing for terminal search commands --------------------
function Set-OptKey($O, [string]$Key, [string]$Val) {
    switch ($Key) {
        'name'   { $O.NamePattern = $Val }
        'ext'    { $O.Extensions = [string[]]@(ConvertTo-ExtList $Val) }
        'type'   { $O.Extensions = [string[]]@(ConvertTo-ExtList $Val) }
        'min'    { $O.MinBytes = [int64]([double]$Val * 1MB) }
        'max'    { $O.MaxBytes = [int64]([double]$Val * 1MB) }
        'text'   { $O.ContentText = $Val }
        'grep'   { $O.ContentText = $Val }
        'newer'  { $O.UseDate = $true; $O.DateNewer = $true;  $O.DateValue = (Get-Date).Date.AddDays(-[double]$Val) }
        'older'  { $O.UseDate = $true; $O.DateNewer = $false; $O.DateValue = (Get-Date).Date.AddDays(-[double]$Val) }
        'sub'    { $O.Recurse = ($Val -ne '0') }
        'hidden' { $O.IncludeHidden = ($Val -ne '0') }
        default  { throw "UNKNOWN OPTION $Key" }
    }
}

# tokens: key=value, key="two words", "quoted bare", or bare
function New-TermOptions([string]$Arg, [string]$DefaultKey) {
    $o = New-Object SliceOptions
    $o.Root = $script:Cwd
    $usedBare = $false
    foreach ($m in [regex]::Matches($Arg, '[A-Za-z]+="[^"]*"|"[^"]*"|\S+')) {
        $tok = $m.Value
        if ($tok -match '^([A-Za-z]+)=(.*)$') {
            $k = $Matches[1].ToLower()
            $v = $Matches[2].Trim('"')
            Set-OptKey $o $k $v
        } elseif (-not $usedBare -and $DefaultKey) {
            Set-OptKey $o $DefaultKey $tok.Trim('"')
            $usedBare = $true
        } else { throw 'SYNTAX' }
    }
    return $o
}

# prints the first $Top rows of the list exactly as the GUI shows them (same numbering as OPEN n / RP$(n))
function Show-TermHits([int]$Top) {
    $r = $script:Ranked
    $sb = New-Object System.Text.StringBuilder
    $n = 0
    foreach ($h in $r) {
        if ($n -ge $Top) { break }
        $n++
        $tag = ''
        if ($h.Extra) { $tag = ' [' + $h.Extra + ']' }
        [void]$sb.Append(('{0,3} {1,10} {2}{3}' -f $n, (Format-Size $h.Length), $h.FullName.ToUpper(), $tag) + "`n")
    }
    if ($n -gt 0) { Write-Term $sb.ToString() }
    if ($r.Count -gt $n) { Write-Term ("... +{0} MORE (SEE LIST ABOVE)`n" -f ($r.Count - $n)) }
}

function Invoke-TermSlice($Opts, [int]$Top, [bool]$Dupes) {
    $Opts.FindDupes = $Dupes
    if (-not $script:Quiet) { Write-Term ('SEARCHING ' + $Opts.Root.ToUpper() + "`n") }
    $sl = Invoke-Slicer $Opts
    $hits = @($sl.Hits)
    if ($Dupes) { $script:SortCol = 5; $script:SortAsc = $true } else { $script:SortCol = 0; $script:SortAsc = $false }
    Set-Results $hits
    if (-not $script:Quiet) { Show-TermHits $Top }
    if ($sl.Error) { Write-Term ('?' + $sl.Error.ToUpper() + "  ERROR`n") }
    if (-not $script:Quiet) {
        Write-Term ("{0} FILES FOUND. ({1} SCANNED, {2:N1}S)`n" -f $hits.Count, $sl.Scanned, $script:LastElapsed)
    }
    $txtStatus.Text = ('✅ Terminal search: {0:N0} files | {1}' -f $hits.Count, (Format-Size $script:ShownTotal))
}

function Invoke-TermStats {
    $arr = @($script:Results)
    if ($arr.Count -eq 0) { Write-Term "?NO RESULTS  ERROR`n"; return }
    $groups = @($arr | Group-Object -Property Ext | ForEach-Object {
        $sum = ($_.Group | Measure-Object -Property Length -Sum).Sum
        [pscustomobject]@{ Ext = $_.Name; Count = $_.Count; Bytes = [int64]$sum }
    } | Sort-Object -Property Bytes -Descending | Select-Object -First 15)
    $max = ($groups | Measure-Object -Property Bytes -Maximum).Maximum
    if (-not $max) { $max = 1 }
    Write-Term "EXTENSION STATISTICS`n"
    foreach ($g in $groups) {
        $label = $g.Ext.ToUpper()
        if (-not $label) { $label = '(NONE)' }
        $bar = '█' * [math]::Max(1, [int](18 * $g.Bytes / $max))
        Write-Term (('{0,-8} {1,6} {2,10} {3}' -f $label, $g.Count, (Format-Size $g.Bytes), $bar) + "`n")
    }
    $tot = ($arr | Measure-Object -Property Length -Sum).Sum
    Write-Term ("{0} FILES, {1}`n" -f $arr.Count, (Format-Size ([int64]$tot)))
}

# ---- BASIC program files: find / pick / load / run ------------------
function Resolve-TermPath([string]$Name) {
    $f = $Name.Trim().Trim('"')
    if ([System.IO.Path]::IsPathRooted($f)) { return $f }
    return (Join-Path $script:Cwd $f)
}

function Find-BasFile([string]$Name) {
    $n = $Name.Trim().Trim('"')
    if (-not $n) { return $null }
    $bases = @()
    if ([System.IO.Path]::IsPathRooted($n)) { $bases += $n }
    else { $bases += (Join-Path $script:Cwd $n); $bases += (Join-Path $script:ProgDir $n) }
    foreach ($b in $bases) {
        foreach ($x in @($b, ($b + '.bas'), ($b + '.BAS'))) {
            if (Test-Path -LiteralPath $x -PathType Leaf) { return (Resolve-Path -LiteralPath $x).ProviderPath }
        }
    }
    return $null
}

function Select-BasFile {
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Title = 'BASIC プログラムを選択 (Choose a BASIC program)'
    $dlg.Filter = 'BASIC programs (*.bas;*.txt)|*.bas;*.txt|All files (*.*)|*.*'
    if (Test-Path -LiteralPath $script:ProgDir) { $dlg.InitialDirectory = $script:ProgDir }
    if ($dlg.ShowDialog($form) -eq [System.Windows.Forms.DialogResult]::OK) { return $dlg.FileName }
    return $null
}

# returns number of numbered lines loaded, or -1 if the file is too big
function Import-BasFile([string]$Path) {
    if ((Get-Item -LiteralPath $Path).Length -gt 1MB) { return -1 }
    $basic.ClearProgram()
    $cnt = 0
    foreach ($ln in (Get-Content -LiteralPath $Path -ErrorAction SilentlyContinue)) {
        if ($ln -match '^\s*(\d+)\s*(.*)$') { $basic.SetLine([int]$Matches[1], $Matches[2]); $cnt++ }
    }
    $script:ListMode = 'prog'
    $script:DirLines = @()
    return $cnt
}

function Invoke-RunFile([string]$Arg) {
    $a = $Arg.Trim()
    $p = $null
    if ($a -eq '?' -or $a -eq '"?"') {
        $p = Select-BasFile
        if (-not $p) { Write-Term "BREAK`n"; Write-Ready; return }
    } else {
        $p = Find-BasFile $a
        if (-not $p) { Write-Term "?FILE NOT FOUND  ERROR`n"; Write-Ready; return }
    }
    Write-Term ('LOADING ' + (Split-Path -Leaf $p).ToUpper() + "`n")
    $c = Import-BasFile $p
    if ($c -lt 0) { Write-Term "?FILE TOO LARGE  ERROR`n"; Write-Ready; return }
    if ($c -eq 0) { Write-Term "?NOT A BASIC TEXT FILE  ERROR`n"; Write-Ready; return }
    $basic.Col = 0
    $basic.Run()
    $pump.Start()
}

function Open-Manual {
    if ($script:ManualPath -and (Test-Path -LiteralPath $script:ManualPath)) { Start-Process -FilePath $script:ManualPath }
    else { Write-Term "?MANUAL.HTML NOT FOUND  ERROR`n" }
}

function Show-Programs {
    $files = @(Get-ChildItem -LiteralPath $script:ProgDir -Filter '*.bas' -File -ErrorAction SilentlyContinue | Sort-Object -Property Name)
    if ($files.Count -eq 0) { Write-Term ('NO PROGRAMS IN ' + $script:ProgDir.ToUpper() + "`n"); return }
    Write-Term ('PROGRAMS IN ' + $script:ProgDir.ToUpper() + "`n")
    foreach ($f in $files) {
        $desc = ''
        foreach ($ln in (Get-Content -LiteralPath $f.FullName -TotalCount 3 -ErrorAction SilentlyContinue)) {
            if ($ln -match '^\s*\d+\s+REM\s+(.*)$') { $desc = $Matches[1]; break }
        }
        Write-Term (('{0,-14} {1}' -f $f.Name.ToUpper(), $desc.ToUpper()) + "`n")
    }
    Write-Term "RUN `"NAME`"  OR  RUN ?  TO PICK A FILE`n"
}

function Install-BundledPrograms {
    foreach ($cand in @($script:ProgDir, (Join-Path $env:APPDATA 'FileSlicer64\Programs'))) {
        try {
            if (-not (Test-Path -LiteralPath $cand)) { [void](New-Item -ItemType Directory -Path $cand -Force -ErrorAction Stop) }
            $probe = Join-Path $cand '.write_test'
            [System.IO.File]::WriteAllText($probe, 'x')
            Remove-Item -LiteralPath $probe -Force
            $script:ProgDir = $cand
            break
        } catch { continue }
    }
    $enc = New-Object System.Text.UTF8Encoding($false)
    try {
        $mp = Join-Path (Split-Path -Parent $script:ProgDir) 'MANUAL.html'
        $mb = (New-Object System.Text.UTF8Encoding($false)).GetBytes((($script:ManualHtml -replace "`r", '') -replace "`n", "`r`n") + "`r`n")
        if (-not (Test-Path -LiteralPath $mp) -or (Get-Item -LiteralPath $mp).Length -ne $mb.Length) { [System.IO.File]::WriteAllBytes($mp, $mb) }
        $script:ManualPath = $mp
    } catch { }
    foreach ($k in $script:Bundled.Keys) {
        $p = Join-Path $script:ProgDir $k
        if (-not (Test-Path -LiteralPath $p)) {
            $text = ($script:Bundled[$k] -replace "`r", '') -replace "`n", "`r`n"
            try { [System.IO.File]::WriteAllText($p, $text + "`r`n", $enc) } catch { }
        }
    }
}

function Invoke-TermLoad([string]$Arg) {
    $a = $Arg.Trim()
    $path = $null
    if ($a -eq '' -or $a -match '^"?\?"?\s*(,.*)?$') {
        $path = Select-BasFile
        if (-not $path) { Write-Term "BREAK`n"; return }
    } else {
        if ($a -match '^"([^"]*)"?') { $name = $Matches[1] }
        else { $name = ($a -replace ',\s*\d+(\s*,\s*\d+)?\s*$', '').Trim() }
        Write-Term ('SEARCHING FOR ' + $name + "`nLOADING`n")
        if ($name.StartsWith('$')) {
            $pat = $name.Substring(1).TrimStart(':')
            if ($pat -match '^\d*:(.*)$') { $pat = $Matches[1] }
            $script:DirLines = Get-DirLines $pat
            $script:ListMode = 'dir'
            $basic.Prog.Clear()
            return
        }
        if ($name -match '[*?]') {
            $rx = ConvertTo-WildRegex $name
            $hit = Get-ChildItem -LiteralPath $script:Cwd -File -ErrorAction SilentlyContinue |
                   Where-Object { [regex]::IsMatch($_.Name, $rx, 'IgnoreCase') } | Select-Object -First 1
            if ($hit) { $path = $hit.FullName }
        } else { $path = Find-BasFile $name }
        if (-not $path) { Write-Term "?FILE NOT FOUND  ERROR`n"; return }
    }
    $c = Import-BasFile $path
    if ($c -lt 0) { Write-Term "?FILE TOO LARGE  ERROR`n" }
    elseif ($c -eq 0) { Write-Term "?NOT A BASIC TEXT FILE  ERROR`n" }
}

function Invoke-TermSave([string]$Arg) {
    if ($Arg -notmatch '^\s*"([^"]*)"?') { Write-Term "?SYNTAX  ERROR`n"; return }
    $name = $Matches[1]
    $overwrite = $false
    if ($name -match '^@\d*:(.*)$') { $overwrite = $true; $name = $Matches[1] }
    if (-not $name) { Write-Term "?MISSING FILE NAME  ERROR`n"; return }
    if (-not [System.IO.Path]::GetExtension($name)) { $name += '.bas' }
    $path = Join-Path $script:Cwd $name
    if ((Test-Path -LiteralPath $path) -and -not $overwrite) { Write-Term "?FILE EXISTS  ERROR`n(USE SAVE`"@:NAME`",8 TO REPLACE)`n"; return }
    $out = foreach ($k in @($basic.Prog.Keys)) { '{0} {1}' -f $k, $basic.Prog[$k] }
    Set-Content -LiteralPath $path -Value $out -Encoding ASCII
    Write-Term ('SAVING ' + $name.ToUpper() + "`n")
}

# ---- BASIC <-> slicer bridge ----------------------------------------
$script:Quiet = $false
$script:InBasic = $false
$basic.HostStr = [System.Func[string,object[],string]]{
    param($n, $a)
    if ($n -eq 'CWD$') { return [string]$script:Cwd }
    if ($n -eq 'FS$') { return [string](Format-Size ([int64][double]$a[0])) }
    $i = [int][double]$a[0]
    if ($i -lt 1 -or $i -gt $script:Ranked.Count) { throw 'ILLEGAL QUANTITY' }
    $h = $script:Ranked[$i - 1]
    switch ($n) {
        'RP$' { return [string]$h.FullName }
        'RN$' { return [string]$h.Name }
        'RD$' { return [string]$h.Modified.ToString('yyyy-MM-dd HH:mm') }
        'RX$' { return [string]$h.Ext.TrimStart('.').ToUpper() }
        'RG$' { return [string]$h.Extra }
    }
    return ''
}
$basic.HostNum = [System.Func[string,object[],double]]{
    param($n, $a)
    if ($n -eq 'RC') { return [double]$script:Ranked.Count }
    $i = [int][double]$a[0]
    if ($i -lt 1 -or $i -gt $script:Ranked.Count) { throw 'ILLEGAL QUANTITY' }
    return [double]$script:Ranked[$i - 1].Length
}
$basic.HostCmd = [System.Func[string,string]]{
    param($c)
    $verb = (($c.Trim() -split '\s+')[0]).ToUpper()
    $allowed = @('FIND','EXT','GREP','NEWER','OLDER','SLICE','DUPES','BIG','REGEX','STATS','SIZE','DIR','CATALOG','CD','PWD','SORT','HEAD','EXPORT','OPEN','EXPLORE','DISK')
    if ($allowed -notcontains $verb) { return 'ILLEGAL DIRECT' }
    $script:InBasic = $true
    $script:Quiet = (@('FIND','EXT','GREP','NEWER','OLDER','SLICE','DUPES','BIG','REGEX') -contains $verb)
    $err = ''
    try { $null = Invoke-TermCommand $c $false }
    catch { $err = $_.Exception.Message.ToUpper() }
    finally { $script:InBasic = $false; $script:Quiet = $false }
    return $err
}

# ---- shell pass-through:  \c = cmd   \p = Windows PowerShell   \7 = PowerShell 7 ----
$script:ShellMode = ''
$script:ActiveShell = $null
$script:ShellMarker = '__FSCWD__'
$script:ShellPending = ''
$script:ShellNewCwd = ''
$script:ShellExpectCwd = $false

function Get-ShellExe([string]$Kind) {
    switch ($Kind) {
        'c' { return $env:ComSpec }
        'p' { return (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe') }
        '7' {
            $g = Get-Command 'pwsh.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($g) { return $g.Definition }
            return $null
        }
    }
    return $null
}

function Get-ShellPrompt([string]$Kind) {
    if ($Kind -eq 'c') { return ($script:Cwd + '>') }
    return ('PS ' + $script:Cwd + '>')
}

# prints shell output, hides our cwd marker, and remembers the folder the shell ended in
function Out-ShellText([string]$Text, [bool]$Final) {
    $marker = $script:ShellMarker
    $t = $script:ShellPending + $Text
    $t = $t -replace "`r", ''
    $t = $t -replace "`t", '    '
    $t = $t -replace '\x1B\[[0-9;?]*[ -/]*[@-~]', ''
    if ($Final -and $t -ne '') { $t += "`n" }
    $parts = $t -split "`n"
    $script:ShellPending = $parts[$parts.Count - 1]
    $out = New-Object System.Text.StringBuilder
    for ($i = 0; $i -lt $parts.Count - 1; $i++) {
        $line = $parts[$i]
        if ($script:ShellExpectCwd) { $script:ShellNewCwd = $line.Trim(); $script:ShellExpectCwd = $false; continue }
        if ($line.StartsWith($marker)) {
            $rest = $line.Substring($marker.Length).Trim()
            if ($rest) { $script:ShellNewCwd = $rest } else { $script:ShellExpectCwd = $true }
            continue
        }
        [void]$out.Append($line + "`n")
    }
    $pend = $script:ShellPending
    if ($pend -ne '' -and -not $script:ShellExpectCwd -and -not ($marker.StartsWith($pend) -or $pend.StartsWith($marker))) {
        [void]$out.Append($pend)
        $script:ShellPending = ''
    }
    if ($out.Length -gt 0) { Write-Term $out.ToString() }
}

function Invoke-Shell([string]$Kind, [string]$CommandLine) {
    $exe = Get-ShellExe $Kind
    if (-not $exe -or -not (Test-Path -LiteralPath $exe)) { Write-Term "?SHELL NOT FOUND  ERROR`n"; return }
    $marker = $script:ShellMarker
    $cp = 65001
    if ($Kind -eq 'c') {
        $argLine = '/d /s /c "' + $CommandLine + ' & echo ' + $marker + '& cd"'
        $cp = [System.Globalization.CultureInfo]::CurrentCulture.TextInfo.OEMCodePage
        $color = [System.Drawing.Color]::FromArgb(230, 230, 230)
    } else {
        $safeCwd = $script:Cwd.Replace("'", "''")
        $wrapper = "`$ProgressPreference='SilentlyContinue'; try { [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding(`$false) } catch { }; Set-Location -LiteralPath '$safeCwd'; " +
                   $CommandLine + "`nWrite-Output ('$marker' + (Get-Location).ProviderPath)"
        $enc = [Convert]::ToBase64String([System.Text.Encoding]::Unicode.GetBytes($wrapper))
        $argLine = '-NoLogo -NoProfile -NonInteractive -OutputFormat Text -EncodedCommand ' + $enc
        $color = [System.Drawing.Color]::FromArgb(120, 200, 255)
    }
    $runner = New-Object ShellRunner
    $script:ActiveShell = $runner
    $script:ShellPending = ''
    $script:ShellNewCwd = ''
    $script:ShellExpectCwd = $false
    Set-BusyState $true
    $prevFg = $script:TermFg
    $script:TermFg = $color
    try {
        if (-not $runner.Start($exe, $argLine, $script:Cwd, $cp)) {
            Write-Term ('?' + $runner.StartError.ToUpper() + "  ERROR`n")
            return
        }
        while (-not $runner.IsDone()) {
            [System.Windows.Forms.Application]::DoEvents()
            Start-Sleep -Milliseconds 30
            $chunk = $runner.Take()
            if ($chunk) { Out-ShellText $chunk $false }
        }
        Out-ShellText ($runner.Take()) $true
    } finally {
        $script:TermFg = $prevFg
        $script:ActiveShell = $null
        Set-BusyState $false
    }
    if ($script:ShellNewCwd -and $script:ShellNewCwd -ne $script:Cwd -and (Test-Path -LiteralPath $script:ShellNewCwd -PathType Container)) {
        $txtPath.Text = $script:ShellNewCwd
    }
}

$script:ShellHelp = @'
SHELL PASS-THROUGH
 \C DIR /S       ONE COMMAND IN CMD.EXE
 \P GET-DATE     WINDOWS POWERSHELL
 \7 GET-DATE     POWERSHELL 7 (PWSH), IF INSTALLED
 \C \P \7 ALONE  STAY IN THAT SHELL
 \S              BACK TO C64 MODE
ESC STOPS A RUNNING COMMAND. NO KEYBOARD INPUT IS
SENT, SO PROMPTS END INSTEAD OF WAITING.
CD IN A SHELL MOVES THE SLICER FOLDER TOO.
'@

function Invoke-ShellSwitch([string]$T) {
    if ($T -notmatch '^\\([A-Za-z0-9?]+)\s*(.*)$') { Write-Term "?SYNTAX  ERROR`n"; Write-Ready; return }
    $sw = $Matches[1].ToLower()
    $rest = $Matches[2]
    $kind = ''
    $names = @{ 'c' = 'CMD.EXE'; 'p' = 'POWERSHELL'; '7' = 'POWERSHELL 7' }
    switch ($sw) {
        { $_ -in 'c', 'cmd' }                    { $kind = 'c' }
        { $_ -in 'p', 'ps', 'powershell' }       { $kind = 'p' }
        { $_ -in '7', 'pw', 'pwsh' }             { $kind = '7' }
        { $_ -in 's', 'q', 'x', 'exit', 'c64' }  {
            $script:ShellMode = ''
            Write-Term "BACK TO C64 MODE`n"
            Write-Ready
            return
        }
        { $_ -in '?', 'h', 'help' }              { Write-Term (($script:ShellHelp -replace "`r", '') + "`n"); Write-Ready; return }
        default                                  { Write-Term "?UNKNOWN SWITCH  ERROR (TRY \?)`n"; Write-Ready; return }
    }
    if (-not (Get-ShellExe $kind)) { Write-Term "?POWERSHELL 7 NOT INSTALLED  ERROR`n"; Write-Ready; return }
    if ($rest -eq '') {
        $script:ShellMode = $kind
        Write-Term ($names[$kind] + " MODE - TYPE \S TO RETURN TO C64`n")
        return
    }
    Invoke-Shell $kind $rest
    if (-not $script:ShellMode) { Write-Ready }
}


# ---- help -------------------------------------------------------------
$script:HelpText = @'
FILES (COMMODORE-DOS STYLE)
 LOAD"$",8 THEN LIST     DIR / CATALOG [PAT]
 CD PATH  CD ..  PWD  DISK
 SCRATCH F   RENAME A TO B   COPY A TO B
SEARCH (RECURSIVE FROM CURRENT FOLDER)
 FIND *MIX*   EXT WAV MP3   GREP TEXT
 REGEX ^\d+.*\.LOG$   BIG 20
 NEWER 7   OLDER 365   DUPES   DELDUP
 SLICE EXT=WAV MIN=5 MAX=500 NAME=*MIX*
   TEXT="TWO WORDS" NEWER=30 OLDER=90 SUB=0
RESULTS
 SORT SIZE|DATE|TYPE|NAME|DIR [ASC|DESC]
 HEAD 20  STATS  SIZE  OPEN n  EXPLORE n
 EXPORT [FILE]  ALIAS X = COMMAND
PROGRAMS
 PROGS  RUN "NAME"  RUN ?  (PICK A FILE)
 LOAD"X.BAS",8  LOAD?  SAVE"X.BAS",8
BASIC V2:  10 PRINT "HI"  RUN  LIST  NEW
 POKE 53280,2 BORDER   POKE 53281,0 SCREEN
 CHR$(147) CLEAR  CHR$(28) RED  CHR$(5) WHITE
 SYS 64738 OR RESET      ESC = RUN/STOP
 SHELLS: \C CMD  \P POWERSHELL  \7 PWSH  \S BACK
 HELP BASIC  HELP FIND  HELP SHELL   MANUAL
'@

$script:HelpTopics = @{
    'SHELL'    = "SHELL PASS-THROUGH`n \C DIR  ONE COMMAND IN CMD.EXE`n \P GET-DATE  WINDOWS POWERSHELL`n \7 ...  POWERSHELL 7 (PWSH)`n \C ALONE STAYS IN THAT SHELL, \S RETURNS.`n ESC STOPS A COMMAND. NO KEYBOARD INPUT IS SENT.`n CD IN A SHELL MOVES THE SLICER FOLDER TOO."
    'MANUAL'   = 'MANUAL - OPEN MANUAL.HTML IN YOUR BROWSER (ALSO F1).'
    'BASIC'    = "SLICER EXTENSIONS FOR BASIC PROGRAMS`n CMD `"FIND *.WAV`"  RUN A TERMINAL COMMAND`n   (FIND EXT GREP NEWER OLDER SLICE DUPES BIG REGEX`n    STATS SIZE DIR CD SORT HEAD EXPORT OPEN EXPLORE)`n RC(0)      NUMBER OF RESULTS`n RP`$(I)     FULL PATH OF RESULT I (1 = FIRST ROW)`n RN`$(I) NAME  RX`$(I) EXTENSION  RD`$(I) DATE  RG`$(I) DUPE GROUP`n RS(I)      SIZE IN BYTES`n FS`$(N)      FORMAT BYTES AS KB/MB/GB`n CWD`$       CURRENT FOLDER`n TI  JIFFY CLOCK (60/SEC)   RND(1)   PEEK/POKE`n`nSEE THE PROGRAMS FOLDER FOR EXAMPLES (PROGS)."
    'FIND'     = 'FIND PATTERN - NAME SEARCH, * AND ? WILDCARDS. FIND "MY SONG" FOR SPACES.'
    'EXT'      = 'EXT WAV MP3 FLAC - SEARCH BY FILE TYPE.'
    'GREP'     = 'GREP TEXT - FILES CONTAINING TEXT (ASCII/UTF-8, UP TO 64 MB).'
    'REGEX'    = 'REGEX PATTERN - .NET REGULAR EXPRESSION ON FILE NAMES. CASE IS KEPT.'
    'BIG'      = 'BIG N - THE N LARGEST FILES UNDER THE CURRENT FOLDER.'
    'NEWER'    = 'NEWER DAYS - FILES MODIFIED IN THE LAST DAYS.'
    'OLDER'    = 'OLDER DAYS - FILES NOT MODIFIED FOR DAYS.'
    'SLICE'    = 'SLICE KEY=VALUE ... KEYS: NAME EXT MIN MAX TEXT NEWER OLDER SUB HIDDEN. ALL FILTERS COMBINE (AND). QUOTE VALUES WITH SPACES.'
    'DUPES'    = 'DUPES - DUPLICATE FILES (SIZE, QUICK HASH, THEN SHA-1). ESC STOPS.'
    'DELDUP'   = 'DELDUP - AFTER DUPES: SEND EXTRA COPIES TO THE RECYCLE BIN, KEEPING THE OLDEST IN EACH GROUP. ASKS FIRST.'
    'SORT'     = 'SORT SIZE|DATE|TYPE|NAME|DIR [ASC|DESC] - RE-SORT THE LIST. BASIC RESULT NUMBERS FOLLOW THIS ORDER.'
    'HEAD'     = 'HEAD N - PRINT THE FIRST N ROWS OF THE LIST.'
    'OPEN'     = 'OPEN N - OPEN ROW N OF THE LIST.'
    'EXPLORE'  = 'EXPLORE N - SHOW ROW N IN EXPLORER.'
    'EXPORT'   = 'EXPORT [FILE.CSV] - SAVE THE LIST AS CSV.'
    'RUN'      = 'RUN - RUN PROGRAM IN MEMORY. RUN 100 - START AT LINE 100. RUN "NAME" - LOAD AND RUN A .BAS FILE (CURRENT FOLDER, THEN PROGRAMS FOLDER). RUN ? - PICK A FILE.'
    'LOAD'     = 'LOAD"$",8 - DIRECTORY. LOAD"NAME.BAS",8 - LOAD PROGRAM. LOAD? - PICK A FILE.'
    'SAVE'     = 'SAVE"NAME.BAS",8 - SAVE PROGRAM. SAVE"@:NAME.BAS",8 REPLACES.'
    'PROGS'    = 'PROGS - LIST THE BUNDLED PROGRAMS.'
    'ALIAS'    = 'ALIAS DF = DUPES - MAKE A SHORTCUT. ALIAS ALONE LISTS. ALIAS DF = REMOVES.'
    'DISK'     = 'DISK - TOTAL/USED/FREE SPACE OF THE CURRENT DRIVE.'
    'SCRATCH'  = 'SCRATCH FILE - RECYCLE A FILE (ASKS FIRST).'
    'RENAME'   = 'RENAME OLD TO NEW.'
    'COPY'     = 'COPY A TO B.'
    'CD'       = 'CD PATH / CD .. - CHANGE FOLDER (ALSO UPDATES THE TARGET BOX).'
    'DIR'      = 'DIR [PATTERN] - LIST THE CURRENT FOLDER IN DISK-DIRECTORY STYLE.'
}

# ---- the command interpreter ------------------------------------------
function Invoke-TermCommand([string]$Line, [bool]$Echo = $true) {
    $t = $Line.Trim()
    if ($basic.State.ToString() -eq 'Input') {
        Write-Term ($t + "`n")
        $basic.ProvideInput($t)
        $pump.Start()
        return
    }
    $isSwitch = $t.StartsWith('\')
    if ($Echo) {
        if ($isSwitch) { Write-Term ($t + "`n") }
        elseif ($script:ShellMode) { Write-Term ((Get-ShellPrompt $script:ShellMode) + ' ' + $t + "`n") }
        elseif ($t -match '^(?i)REGEX\b') { Write-Term ($t + "`n") }
        else { Write-Term ($t.ToUpper() + "`n") }
    }
    if ($t -eq '') { return }
    if ($isSwitch) { Invoke-ShellSwitch $t; return }
    if ($script:ShellMode) {
        if ($t -eq 'exit') { $script:ShellMode = ''; Write-Term "BACK TO C64 MODE`n"; Write-Ready }
        else { Invoke-Shell $script:ShellMode $t }
        return
    }

    if ($t -match '^(\d+)\s*(.*)$') {
        $script:ListMode = 'prog'
        $script:DirLines = @()
        $basic.SetLine([int]$Matches[1], $Matches[2])
        return
    }

    $cmd = ''
    $arg = ''
    if ($t -match '^([A-Za-z]+)(.*)$') { $cmd = $Matches[1].ToUpper(); $arg = $Matches[2].Trim() }
    switch ($cmd) { 'CATALOG' { $cmd = 'DIR' } 'DLOAD' { $cmd = 'LOAD' } 'DSAVE' { $cmd = 'SAVE' } }

    switch ($cmd) {
        'HELP' {
            if ($arg) {
                $k = $arg.ToUpper().Trim()
                if ($script:HelpTopics.ContainsKey($k)) { Write-Term ($script:HelpTopics[$k] + "`n") }
                else { Write-Term "NO HELP FOR $k`n" }
            } else { Write-Term (($script:HelpText -replace "`r", '') + "`n") }
            Write-Ready; return
        }
        'CLS'   { Write-Term ([string][char]147); Write-Ready; return }
        'RESET' { Reset-Term; return }
        'EXIT'  { $split.Panel2Collapsed = $true; return }
        'QUIT'  { $split.Panel2Collapsed = $true; return }
        'PWD'   { Write-Term ($script:Cwd.ToUpper() + "`n"); Write-Ready; return }
        'PROGS' { Show-Programs; Write-Ready; return }
        'MANUAL' { Open-Manual; Write-Ready; return }
        'CD' {
            if ($arg -eq '') { Write-Term ($script:Cwd.ToUpper() + "`n"); Write-Ready; return }
            $arg = $arg.Trim('"')
            if ($arg -eq '..') { $target = Split-Path -Parent $script:Cwd }
            elseif ([System.IO.Path]::IsPathRooted($arg)) { $target = $arg }
            else { $target = Join-Path $script:Cwd $arg }
            if ($target -and (Test-Path -LiteralPath $target -PathType Container)) {
                $txtPath.Text = (Resolve-Path -LiteralPath $target).ProviderPath
                Write-Term ($script:Cwd.ToUpper() + "`n")
            } else { Write-Term "?PATH NOT FOUND  ERROR`n" }
            Write-Ready; return
        }
        'DIR' { Write-Term ((Get-DirLines $arg) -join "`n"); Write-Term "`n"; Write-Ready; return }
        'DISK' {
            try {
                $di = New-Object System.IO.DriveInfo([System.IO.Path]::GetPathRoot($script:Cwd))
                $used = $di.TotalSize - $di.AvailableFreeSpace
                Write-Term ('DRIVE  ' + $di.Name + "`nTOTAL  " + (Format-Size $di.TotalSize) + "`nUSED   " + (Format-Size $used) + "`nFREE   " + (Format-Size $di.AvailableFreeSpace) + "`n")
            } catch { Write-Term "?DEVICE NOT PRESENT  ERROR`n" }
            Write-Ready; return
        }
        'LOAD' { Invoke-TermLoad $arg; Write-Ready; return }
        'SAVE' { Invoke-TermSave $arg; Write-Ready; return }
        'LIST' {
            if ($script:ListMode -eq 'dir' -and $basic.Prog.Count -eq 0) { Write-Term (($script:DirLines -join "`n") + "`n") }
            else {
                $sb = New-Object System.Text.StringBuilder
                foreach ($k in @($basic.Prog.Keys)) { [void]$sb.Append(('{0} {1}' -f $k, $basic.Prog[$k]) + "`n") }
                Write-Term $sb.ToString()
            }
            Write-Ready; return
        }
        'NEW' {
            $basic.ClearProgram()
            $script:ListMode = 'prog'
            $script:DirLines = @()
            Write-Ready; return
        }
        'RUN' {
            if ($arg -eq '') {
                if ($script:ListMode -eq 'dir' -and $basic.Prog.Count -eq 0) { Write-Term "?SYNTAX  ERROR`n"; Write-Ready; return }
                $basic.Col = 0; $basic.Run(); $pump.Start(); return
            }
            if ($arg -match '^\d+$') { $basic.Col = 0; $basic.RunFrom([int]$arg); $pump.Start(); return }
            Invoke-RunFile $arg
            return
        }
        'FIND'  { Invoke-TermSlice (New-TermOptions $arg 'name') 40 $false; Write-Ready; return }
        'GREP'  { Invoke-TermSlice (New-TermOptions $arg 'text') 40 $false; Write-Ready; return }
        'NEWER' { Invoke-TermSlice (New-TermOptions $arg 'newer') 40 $false; Write-Ready; return }
        'OLDER' { Invoke-TermSlice (New-TermOptions $arg 'older') 40 $false; Write-Ready; return }
        'SLICE' { Invoke-TermSlice (New-TermOptions $arg '') 40 $false; Write-Ready; return }
        'EXT' {
            if ($arg -notmatch '=') { $arg = 'ext=' + ($arg -replace '\s+', ',') }
            Invoke-TermSlice (New-TermOptions $arg 'ext') 40 $false
            Write-Ready; return
        }
        'REGEX' {
            if (-not $arg) { Write-Term "?MISSING PATTERN  ERROR`n"; Write-Ready; return }
            try { [void][regex]::new($arg) } catch { Write-Term "?BAD REGEX  ERROR`n"; Write-Ready; return }
            $o = New-Object SliceOptions
            $o.Root = $script:Cwd
            $o.NamePattern = $arg
            $o.UseRegex = $true
            Invoke-TermSlice $o 40 $false
            Write-Ready; return
        }
        'DUPES' { Invoke-TermSlice (New-TermOptions $arg '') 60 $true; Write-Ready; return }
        'BIG' {
            $n = 20
            if ($arg -match '^\d+') { $n = [int]$Matches[0] }
            Invoke-TermSlice (New-TermOptions '' '') $n $false
            Write-Ready; return
        }
        'DELDUP' {
            $groups = @($script:Results | Where-Object { $_.Extra } | Group-Object -Property Extra)
            if ($groups.Count -eq 0) { Write-Term "?RUN DUPES FIRST  ERROR`n"; Write-Ready; return }
            $extras = New-Object System.Collections.ArrayList
            foreach ($g in $groups) {
                $sorted = @($g.Group | Sort-Object -Property Modified)
                for ($i = 1; $i -lt $sorted.Count; $i++) { [void]$extras.Add($sorted[$i]) }
            }
            $bytes = 0L
            foreach ($x in $extras) { $bytes += $x.Length }
            $msg = ("重複コピー {0} 個 ({1}) をごみ箱へ送りますか?`n(Send {0} extra copies ({1}) to the Recycle Bin?`nThe OLDEST copy in each group is kept.)" -f $extras.Count, (Format-Size $bytes))
            $r = [System.Windows.Forms.MessageBox]::Show($form, $msg, 'DELDUP', 'YesNo', 'Warning')
            if ($r -ne [System.Windows.Forms.DialogResult]::Yes) { Write-Term "BREAK`n"; Write-Ready; return }
            $ok = 0; $bad = 0
            foreach ($x in $extras) {
                try {
                    [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile($x.FullName, 'OnlyErrorDialogs', 'SendToRecycleBin')
                    $script:Results.Remove($x)
                    $ok++
                } catch { $bad++ }
            }
            Show-Results
            Write-Term ("RECYCLED {0} FILE(S), {1} FAILED`n" -f $ok, $bad)
            Write-Ready; return
        }
        'SORT' {
            $words = @($arg.ToUpper() -split '\s+' | Where-Object { $_ })
            $map = @{ SIZE = 0; DATE = 1; TYPE = 2; NAME = 3; DIR = 4; NOTE = 5 }
            $key = 'SIZE'
            if ($words.Count -gt 0) { $key = $words[0] }
            if (-not $map.ContainsKey($key)) { Write-Term "?SYNTAX  ERROR`n"; Write-Ready; return }
            $script:SortCol = $map[$key]
            $script:SortAsc = ($map[$key] -ge 2)
            if ($words -contains 'ASC') { $script:SortAsc = $true }
            if ($words -contains 'DESC') { $script:SortAsc = $false }
            Show-Results
            Write-Term ('SORTED BY ' + $key + "`n")
            Write-Ready; return
        }
        'HEAD' {
            $n = 20
            if ($arg -match '^\d+') { $n = [int]$Matches[0] }
            Show-TermHits $n
            Write-Ready; return
        }
        'STATS' { Invoke-TermStats; Write-Ready; return }
        'SIZE' {
            $sl = Invoke-Slicer (New-TermOptions $arg '')
            $tot = 0L
            foreach ($h in $sl.Hits) { $tot += $h.Length }
            Write-Term ("{0:N0} FILES, {1}, {2:N0} BLOCKS`n" -f $sl.Hits.Count, (Format-Size $tot), [math]::Ceiling($tot / 254.0))
            Write-Ready; return
        }
        'OPEN' {
            $i = [int]$arg
            if ($i -ge 1 -and $i -le $script:Ranked.Count) { Start-Process -FilePath $script:Ranked[$i - 1].FullName }
            else { Write-Term "?ILLEGAL QUANTITY  ERROR`n" }
            Write-Ready; return
        }
        'EXPLORE' {
            $i = [int]$arg
            if ($i -ge 1 -and $i -le $script:Ranked.Count) {
                Start-Process -FilePath 'explorer.exe' -ArgumentList ('/select,"' + $script:Ranked[$i - 1].FullName + '"')
            } else { Write-Term "?ILLEGAL QUANTITY  ERROR`n" }
            Write-Ready; return
        }
        'EXPORT' {
            if ($script:Results.Count -eq 0) { Write-Term "?NO RESULTS  ERROR`n"; Write-Ready; return }
            $f = $arg.Trim('"')
            if (-not $f) { $f = 'slice_results.csv' }
            $f = Resolve-TermPath $f
            Export-ResultsTo $f
            Write-Term ('SAVED ' + $script:Results.Count + ' ROWS TO ' + $f.ToUpper() + "`n")
            Write-Ready; return
        }
        'ALIAS' {
            if ($arg -eq '') {
                foreach ($k in ($script:Aliases.Keys | Sort-Object)) { Write-Term (('{0} = {1}' -f $k.ToUpper(), $script:Aliases[$k]) + "`n") }
                Write-Ready; return
            }
            $parts = $arg -split '\s*=\s*', 2
            if ($parts.Count -lt 2) { Write-Term "?SYNTAX  ERROR`n"; Write-Ready; return }
            $name = $parts[0].Trim()
            if ($parts[1].Trim() -eq '') { $script:Aliases.Remove($name); Write-Term ("ALIAS $($name.ToUpper()) REMOVED`n") }
            else { $script:Aliases[$name] = $parts[1].Trim(); Write-Term ("ALIAS $($name.ToUpper()) SET`n") }
            Write-Ready; return
        }
        'SCRATCH' {
            $f = $arg.Trim('"')
            if (-not $f) { Write-Term "?MISSING FILE NAME  ERROR`n"; Write-Ready; return }
            $p = Resolve-TermPath $f
            if (-not (Test-Path -LiteralPath $p -PathType Leaf)) { Write-Term "?FILE NOT FOUND  ERROR`n"; Write-Ready; return }
            $r = [System.Windows.Forms.MessageBox]::Show($form, "ごみ箱へ送りますか? (Send to the Recycle Bin?)`n`n$p", 'SCRATCH', 'YesNo', 'Warning')
            if ($r -eq [System.Windows.Forms.DialogResult]::Yes) {
                [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile($p, 'OnlyErrorDialogs', 'SendToRecycleBin')
                Write-Term ('SCRATCHED ' + (Split-Path -Leaf $p).ToUpper() + "`n")
            } else { Write-Term "BREAK`n" }
            Write-Ready; return
        }
        'RENAME' {
            $parts = @($arg -split '\s+TO\s+', 2)
            if ($parts.Count -lt 2) { Write-Term "?SYNTAX  ERROR`n"; Write-Ready; return }
            $from = Resolve-TermPath $parts[0]
            $to = $parts[1].Trim().Trim('"')
            if (-not (Test-Path -LiteralPath $from)) { Write-Term "?FILE NOT FOUND  ERROR`n"; Write-Ready; return }
            Rename-Item -LiteralPath $from -NewName (Split-Path -Leaf $to) -ErrorAction Stop
            Write-Term "RENAMED`n"
            Write-Ready; return
        }
        'COPY' {
            $parts = @($arg -split '\s+TO\s+', 2)
            if ($parts.Count -lt 2) { Write-Term "?SYNTAX  ERROR`n"; Write-Ready; return }
            $from = Resolve-TermPath $parts[0]
            $to = Resolve-TermPath $parts[1]
            if (-not (Test-Path -LiteralPath $from -PathType Leaf)) { Write-Term "?FILE NOT FOUND  ERROR`n"; Write-Ready; return }
            Copy-Item -LiteralPath $from -Destination $to -ErrorAction Stop
            Write-Term "COPIED`n"
            Write-Ready; return
        }
    }

    # anything else: a BASIC statement
    $basic.Col = 0
    $basic.Direct($t)
    $pump.Start()
}

function Submit-Term([string]$Line) {
    $st = $basic.State.ToString()
    if ($st -eq 'Running') { return }
    if ($script:Busy) { Write-Term "?DEVICE NOT PRESENT  ERROR`n"; return }
    if ($Line.Trim() -ne '' -and $st -ne 'Input') {
        [void]$script:History.Add($Line)
        $script:HistIdx = $script:History.Count
        $parts = $Line.Trim() -split '\s+', 2
        if ($parts[0] -and -not $script:ShellMode -and -not $Line.Trim().StartsWith('\') -and $script:Aliases.ContainsKey($parts[0])) {
            $Line = [string]$script:Aliases[$parts[0]]
            if ($parts.Count -gt 1) { $Line += ' ' + $parts[1] }
        }
    }
    try { Invoke-TermCommand $Line }
    catch {
        Write-Term ('?' + $_.Exception.Message.ToUpper() + "  ERROR`n")
        Write-Ready
    }
}

# ---- persistent settings ------------------------------------------------
$script:SettingsPath = Join-Path $env:APPDATA 'FileSlicer64\settings.json'
function Save-Settings {
    try {
        $dir = Split-Path -Parent $script:SettingsPath
        if (-not (Test-Path -LiteralPath $dir)) { [void](New-Item -ItemType Directory -Path $dir -Force) }
        [pscustomobject]@{
            Path = $txtPath.Text; Types = $txtTypes.Text; Name = $txtName.Text; Text = $txtText.Text
            MinMB = $txtSizeMin.Text; MaxMB = $txtSizeMax.Text
            Regex = $chkRegex.Checked; Recurse = $chkSub.Checked; Hidden = $chkHidden.Checked
            Aliases = $script:Aliases
        } | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $script:SettingsPath -Encoding UTF8
    } catch { }
}
function Restore-Settings {
    if (-not (Test-Path -LiteralPath $script:SettingsPath)) { return }
    try {
        $s = Get-Content -LiteralPath $script:SettingsPath -Raw | ConvertFrom-Json
        if ($s.Path)  { $txtPath.Text = [string]$s.Path }
        if ($s.Types) { $txtTypes.Text = [string]$s.Types }
        $txtName.Text = [string]$s.Name
        $txtText.Text = [string]$s.Text
        $txtSizeMin.Text = [string]$s.MinMB
        $txtSizeMax.Text = [string]$s.MaxMB
        if ($null -ne $s.Regex)   { $chkRegex.Checked = [bool]$s.Regex }
        if ($null -ne $s.Recurse) { $chkSub.Checked = [bool]$s.Recurse }
        if ($null -ne $s.Hidden)  { $chkHidden.Checked = [bool]$s.Hidden }
        if ($s.Aliases) { foreach ($p in $s.Aliases.PSObject.Properties) { $script:Aliases[$p.Name] = [string]$p.Value } }
    } catch { }
}

$termIn.Add_KeyDown({
    param($s, $e)
    $k = $e.KeyCode
    if ($k -eq 'Return') {
        $e.SuppressKeyPress = $true
        $line = $termIn.Text
        $termIn.Clear()
        Submit-Term $line
    }
    elseif ($k -eq 'Up') {
        $e.SuppressKeyPress = $true
        if ($script:HistIdx -gt 0) { $script:HistIdx--; $termIn.Text = [string]$script:History[$script:HistIdx]; $termIn.SelectionStart = $termIn.TextLength }
    }
    elseif ($k -eq 'Down') {
        $e.SuppressKeyPress = $true
        if ($script:HistIdx -lt $script:History.Count - 1) { $script:HistIdx++; $termIn.Text = [string]$script:History[$script:HistIdx] }
        else { $script:HistIdx = $script:History.Count; $termIn.Clear() }
    }
    elseif ($k -eq 'Escape') {
        $e.SuppressKeyPress = $true
        if ($script:ActiveShell) { $script:ActiveShell.Kill(); return }
        if ($script:Busy -and $script:ActiveSlicer) { $script:ActiveSlicer.Cancel = $true; return }
        $st = $basic.State.ToString()
        if ($st -eq 'Running' -or $st -eq 'Input') {
            $pump.Stop()
            $basic.Break()
            $basic.Col = 0
            Write-Ready
        }
    }
})
$termOut.Add_Click({ $termIn.Focus() })

# ---------------------------------------------------------------------
#  Go!
# ---------------------------------------------------------------------
$form.Add_Load({ Update-Layout })
$form.Add_Shown({
    Update-Layout
    Restore-Settings
    Install-BundledPrograms
    try { $split.SplitterDistance = [int]($split.Height * 0.55) } catch { }
    Reset-Term
    $form.Activate()
})
$form.Add_FormClosing({ Save-Settings; $pump.Stop(); if ($script:ActiveSlicer) { $script:ActiveSlicer.Cancel = $true } })

[void]$form.ShowDialog()
