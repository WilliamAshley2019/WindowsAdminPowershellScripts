File Slicer v16
===============
1. Right-click the zip > Properties > Unblock (if shown), then extract.
2. Double-click Run_FileSlicer.bat
3. Press F1 for the manual (MANUAL.html), F2 for the terminal, F5 to slice.

Programs\   bundled .BAS programs (RUN ? in the terminal to pick one)
MANUAL.html full tutorial and reference - opens in any browser, prints nicely

Fixed in v16: "Unable to find type [Func]" on Windows PowerShell 5.1.
New in v16:   \c / \p / \7 shell pass-through, MANUAL command and F1.
